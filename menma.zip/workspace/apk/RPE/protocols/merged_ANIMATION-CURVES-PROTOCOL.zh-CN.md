# 自定义动画曲线 v1

普通事件、扩展事件、噪域数值事件、全局事件与着色器参数轨道共用同一求值规则。含自定义曲线的 Next 文件 META.RPEVersion 至少为 250；这是谱面格式版本，不改变编辑器程序版本。曲线仅在实际采样时编译，标准缓动保留原路径。曲线快照存于事件中，不依赖设备上的模板库。

## 数据

事件可包含 customEasing：

```json
{"curve":{"version":1,"name":"轻微回弹","nodes":[{"x":0,"y":0,"mode":"corner","out":[0.2,0]},{"x":0.7,"y":1.15,"mode":"smooth","in":[0.45,1.15],"out":[0.8,1.15]},{"x":1,"y":1,"mode":"corner","in":[0.9,1]}]}}
```

x 是事件持续秒数的归一化时间，y 是起终值的过渡进度；沿用现有事件的 TempoMap / bpmfactor 换算。不是直接按拍数线性插值，也不是“调速曲线”面板中的距离缓动。每条曲线 2–256 节点，首尾必须是 (0,0) / (1,1)，x 严格递增，y 允许超调与回退，绝对值不超过 10000。in / out 是绝对控制坐标，X 限制在节点与对应相邻节点之间，Y 同样有界。

模式 auto 自动决定切线，smooth 为对齐平滑，corner 的两柄独立；linear / hold 定义本节点至下一节点的线性 / 保持段。保持段在下一个节点时间跳到其值。smooth 对齐是编辑约束，播放器直接求实际控制柄。源定义、节点和事件上的未知字段在原生保存中保留。Schema 位于 schemas/animation-curve-v1.schema.json；相邻次序、首尾坐标与控制柄局部边界由运行时补充校验。

customEasing 优先于 bezier、easingType 和 easingLeft/Right。数值及颜色按曲线插值；文本沿用逐字和 %P% 语义；不插值的数据继续保持起值。普通、扩展、噪域、全局、着色器、取样及预览统一使用 event-easing.mjs。速度使用分段三次 Bezier 的解析积分 ∫Y(t)X'(t)dt，覆盖负速、BPM 变化、线倍率和零时长边界。编译按曲线对象弱缓存，并最多共享 128 条相同控制定义。

## 裁切与编辑

切分在 customEasing 中保存 domain:[left,right]，保留 sourceStart / sourceEnd 作为原数值基准。不得只把两端重归一化，因为两端可能同值而中间不平直。相邻切分段共享完整曲线快照，可在删除分界时恢复原区间。区间替换、文字排线和追踪工具也使用同一裁切规则。

修改源曲线保留 domain 和数值基准，同时重算事件边界值。属性编辑起终值会重算源数值映射；若裁切的两端进度相等，无法单独改出不同端值时明确拒绝，用户可同时改两端或重新调用模板。调用新的模板按当前事件的起终值重新应用完整模板。

一次拖拽或一次数值编辑作为一次撤销操作，支持 Esc 取消，预览不写历史。多选应用只复制曲线，不复制第一项的时间、数值、所属线或私有字段。绑定组同步曲线字段，切回标准缓动会移除 customEasing。未知提供方的全局事件继续只读。浮窗键盘路由只接管自身焦点，文本复制粘贴、撤销和删除不穿透到谱面；失焦取消拖拽，关闭清除观察器、帧任务和选择观察。首次撤销恢复原有标准缓动/Bezier 字段，多选撤销恢复每个目标的独立快照；失败的提交不进入浮窗历史。

控制柄转过本节点的垂直时间边界时，仅限制 X 并保留 Y，不把整条控制向量缩为零。对齐平滑模式先约束正在拖动的柄，再沿其反向对齐另一柄；遇到相邻节点的时间边界时沿原方向缩短。屏幕上不足 18 像素的柄以虚线与空心方柄提供独立命中位置；这是显示辅助，不改变保存坐标，点击不产生编辑，开始拖动后从可见位置调整。已保存的零长度柄也可通过该位置重新拉开。

## 编辑器内浮窗与模板

属性中的标准缓动与自定义模板为同级折叠组。曲线编辑使用编辑器内可拖拽、可调整大小的大浮窗，不创建浏览器或桌面子窗口。拖动标题栏移动，右下角调整大小，标题栏双击或四角放大按钮放大/还原。位置、尺寸、放大状态、时间区间、纵向尺度和吸附设置统一使用本地偏好服务，键为 rpen-animation-curve-view-v2。浮窗直接继承当前语言和皮肤。关闭后不调度帧或继续观察会话。主谱面或选择变化时禁止覆盖旧事件。

播放按钮与空格使用 animation-curve-preview.mjs 的共用时钟，曲线标点和谱面预览同步循环选中事件的秒数区间；每轮时长沿用属性草稿预览的 0.3–3 秒范围，裁切事件使用 domain 对应的源进度。普通、扩展、多线、噪域、全局及着色器参数分别提供有界的事件轨道预览快照，不复制音符数组，不写入会话、播放位置、音乐或撤销历史。快照只在开始或编辑时更新，逐帧仅读时钟。停止、失焦、选择失效、帮助及关闭释放预览状态；面板关闭时不引入持续取样。无可用接口时明确提示原因。

浮窗根据实际宽高调整字体、SVG 图标、控件、间距、属性栏比例和画布坐标标注，紧凑布局以浮窗本身尺寸触发。图标统一为 24 单位描边 SVG，继承皮肤颜色；选择、窗口放大/还原、适合曲线、模板另存/更新及文件导入/导出使用各自语义图形，按钮提供本地化悬停与无障碍名称。

V 选择、A 添加、D 删除工具，Delete / Backspace 删除内部节点；Shift 多选、框选；双击形状保持加点；拖曲线段调整弯曲；Shift 锁轴，Alt 断开控制柄；Ctrl+Z / Ctrl+Shift+Z / Ctrl+Y 撤销重做，Esc 回退拖拽，空格预览，F 适合窗口，? / F1 详细帮助。滚轮纵轴缩放，Ctrl+滚轮横轴缩放，Shift+滚轮平移时间，中键或 Alt+空白处拖拽平移。文本输入保持原生快捷键。帮助内有平滑进出、轻微超调、先退后进、中途停顿、落地回弹和阶梯切换六组实例，均配有曲线、节点、控制柄和坐标图示，可直接载入并撤销。图示与载入内容共享同一份定义。帮助在浮窗内显示，不阻断编辑器其他区域。

模板库使用已有本地偏好服务，键 rpen-animation-curves-v1，最多 512 项。模板记录 id / name / curve，文件格式为 {format:"rpen-animation-curves",version:1,templates:[...]}，扩展名 .rpencurve，支持 JSON 导入。名称冲突保留双方并加编号。导入不覆盖旧库；名称编辑与更新只修改模板，事件始终持有独立副本。可把导入谱面的曲线另存为模板。模板或视图保存失败必须可见，不能自动清空旧库。

## 导出

### 空间节点与整体轨迹

空间节点缓动作用于所选来源事件的完整时间区间（首值、尾值为同一事件），不凭同拍邻接改写另一事件或另一轴。复用标准缓动选择器、自定义模板库和大浮窗曲线编辑器，支持标准裁切边界与 Bézier 控制点；原生绑定组仍遵循普通事件事务规则。草稿预览与已提交谱面分离，取消、来源切换和关闭时清除，提交保留线、层、起止时间及未知字段并更新几何缓存。整体公式轨迹不求普通事件缓动，面板显示原因，不能写入无效的 easingType 冒充修改；零时长事件同样明确说明。

当前面显示选项保存在本机空间视图设置，默认全部开启，所在区域默认折叠。各绘制阶段按 `planeLines/planeNotes/planeHits/planeUI/planeNumbers/planeArrows/planeNoise/planeShaders` 过滤，未改写全局预览偏好、事件和撤销状态；独立音符虚影明确绕开这些当前面选项。突出编辑面节点默认开启，匹配当前编辑面的全局拍数；使用共享 SVG 叠层和 CSS 虚线动画，静止时不请求整谱刷新，关闭、切回时间轴和销毁时隐藏或清理。节点框沿用各节点投影与透视大小，减少动态效果时停止虚线移动。

空间线号列表使用与多线相同的行组件及表达式解析（数字、范围、分组、all、@notes/@events），但状态保存在独立的本机项目视图键和 `viewState.spatialLines` 中，仅含 `enabled/indices/expression`，不读写多线模式、合并与线号值。筛选默认关闭；开启后几何任务和命中索引仅生成列表内曲线与节点，属性、删除和放置同样校验目标，当前面与音符虚影保持原预览范围。强制曲线不透明、节点数字开关默认关闭，保存在本机空间视图设置；前者覆盖曲线事件与皮肤透明度但保留边界淡出，后者在节点自身透视变换内绘制纯数字，不写谱面事件。

“空间轨迹”将普通事件各层的移动、旋转、透明度及扩展缩放、文字事件首尾映射为节点。节点来源保留所属线、层、事件及首尾，不将同拍不同属性当成同一个数据对象；所有修改仍通过原事件事务提交。三维显示和取样参数只保存在本机，不进入谱面。入口归入谱面工具的编辑模式组；空间视图仍使用原预览区域，查看与编辑合并，切回时间轴隐藏全部叠层。坐标显示统一一位小数与坐标对，数值编辑保存完整精度。网格和物件吸附均有接近阈值，移动逐轴独立；物件吸附优先，远离时自由移动。物件大小默认透视，边界渐隐；当前前景 Shader 保留采样覆盖率，辅助线号、箭头在其后透明叠加，普通预览和导出合成不变。其他时刻音符以全可见时间范围的密集采样叠加为渐隐虚影，共用两张 GPU 绘制层；时间相位固定以复用绘制指令，缓存上限 120000 个图元，并按密度自适应采样数量。透视与边界、时间淡出在 GPU 顶点阶段计算；密集时使用分档离屏分辨率，避免逐帧重分配，当前面保持原显示精度。普通预览和视频渲染仍使用相同事件数据。

空间插点切过 Bézier 时，使用相同三次控制点转换为 customEasing 后保存裁切 domain 与源端值。整体轨迹的无损切分使用 `trajectory.domain:[a,b]`，满足 `0≤a<b≤1`；端点编辑可保存 `trajectory.offsets:{x:[x0,x1],y:[y0,y1],rotation:[r0,r1]}`。先将事件进度映射到 domain，取原轨迹，再按映射后的进度插值对应 offsets 并相加。钩定整体轨迹固定取事件进度0。含这两个可选字段的 Next 谱面格式版本至少为251（程序版本不变）。完整定义见 `schemas/trajectory-v1.schema.json`。

相同来源轨迹的相邻裁切段删除分界时合并 domain；相同自定义曲线与源端值的相邻裁切段同样恢复原 domain。其他删除操作连接保留的首尾，用户可一步撤销。整体轨迹在原生保存中保留完整定义，RPE 导出仍通过原来的碎事件转换，取样包含 domain 与 offsets。

RPEN / Next JSON / PEZ 保存完整定义，重新打开后可继续编辑；同内容定义在解析时共享对象，不形成外部依赖。RPE 默认将自定义缓动切碎成原生分段线性事件；保留事件未知字段，拆分绑定组解除以防碎片联动。内部按事件秒数切分，再转换为拍数。切分先覆盖所有节点，用三次 Bezier 控制包络约束整段误差，速度另约束每段积分与部分区间的累计距离。默认相对数值容差 0.001、距离容差 0.1；透明度等字段仍服从 RPE 自身的整数精度。文本为有界离散取样，过渡时刻误差控制在源事件持续时间的 0.00001 内。

每事件最多 8192 段，每次导出最多一百万事件；超预算明确失败，保留原谱面，不能输出缺失曲线。Hold 跳变必要时用 RPE 瞬时边界事件表达。关闭切碎而仍含自定义缓动时拒绝 RPE 导出。RPE 仍不支持噪域与全局事件，必须沿用原本的明确移除确认，不能把缓动切碎当作两个事件系统的兼容实现。
# 声部分离使用指南

入口：**谱面工具 → 音频分析 → 声部与分析音源**。不需要 AI API Key。

## 桌面端

1. 打开需要处理的谱面，确认原音乐可播放。
2. 首次打开音频分析时，阅读磁盘占用提示，并选择音频工具存放位置；建议使用空间充足的非系统盘。取消选择不会开始安装或分离，也不会静默选择系统盘。随后点击 **一键准备分离环境**，一般选 **安装（CPU）**，有兼容 NVIDIA 显卡时可选加速版。
3. 等待下载、安装、检查完成。不需要预装 Python、输入命令或修改 PATH。下载失败后可以重试；详情中保留安装日志。
4. 点击 **分离当前音乐**，默认四声部。首次下载模型，后续可复用。
5. 勾选人声、鼓、贝斯等音源，至少保留一项。编辑器播放按钮会播放所选声部的混合；倍速、保调、定位、暂停和继续均可用。波形/频谱以不同颜色并排显示各项，AI 未指定音源时分析当前混合。

四声部包含人声、鼓、贝斯、其他配器；六声部另含吉他、钢琴，但仍可能串音。模型和依赖不随桌面包捆绑，首次使用需要网络和数 GB 可用空间。CPU 较慢，支持的 NVIDIA 设备可加速。分离过程和音频留在本机。

| 平台 | 操作 |
| --- | --- |
| Windows x64 | 一键准备，CPU 或 NVIDIA 加速 |
| Apple 芯片 macOS | 一键准备，选择 CPU |
| Linux x64 | 一键准备，CPU 或 NVIDIA 加速；需满足预编译依赖的系统要求 |
| Intel macOS / ARM Linux / ARM Windows | 当前没有完整的一键依赖组合；使用配置好的 Demucs 环境，或导入外部分离结果 |

一键安装会按平台显示支持情况。Windows x64 的全新安装与分离经过实测；其他列出的一键平台已核对依赖与下载目标，仍需对应平台实测。不能把“桌面包可启动”视为所有音频推理库均可安装。

首次使用前必须由用户选择位置，三套工具的新安装环境、Python、模型和结果均使用所选文件夹下的 `RPEN-Audio`，本机用户数据目录只记录位置。模型和环境可能占用数 GB 至数十 GB，结果与下载缓存还会持续增长。通过 AI 或其他入口发起安装、选择环境或生成本机分析任务时，也会进行同一位置检查；并发请求共用一次引导。位置设置按本机保存，不随谱面改变。更新或移动编辑器不会要求重新安装。安装成功并通过检查后才切换环境配置，失败时保留原有配置。新建的 Python 只供本功能使用，不注册为系统 Python。

升级前已有运行环境的用户同样需要确认存放位置；已有环境保留原位，模型和缓存迁往所选位置。此前已经通过目录管理完成选择或迁移的用户无需再次选择。

### 模型与缓存位置

桌面端点击 **模型与缓存位置…**，可分别打开声部分离、起音检测、AI 节奏生成的模型、结果缓存、下载缓存或工具数据目录，也可查看运行环境位置。

首次尚未设置时，可在此点击 **选择存放位置…** 重新打开引导。设置完成后，点击 **迁移模型与缓存…** 并选择目标文件夹，经确认后在其中新建 `RPEN-Audio`。迁移涵盖三套工具的模型、结果、安装下载缓存、推理缓存和临时数据，后续下载与处理使用新位置；位置随本机保存，重启或更新后继续使用，不写入谱面。已有 Python、虚拟环境、源码及其配置保留原位，避免破坏路径依赖。

迁移期间禁止启动安装、分离或检测；已有任务未结束时不可迁移。迁移前检查剩余空间与目录关系，拒绝覆盖已有的 `RPEN-Audio`，不跟随目录链接或指向数据目录外的文件链接。新副本逐文件校验并完成持久配置切换后，才逐一删除仍与已校验副本一致的原文件；上述数据子目录以外的文件和发生变化的原文件保留，不递归删除原工具目录。复制、校验或配置写入失败时继续使用原目录，未完成的副本保留并报告位置。切换后清理失败不影响新位置，界面会提示遗留原缓存。中断后以持久配置为准；配置指向的磁盘不可用时提示错误，不静默改回系统盘或重新下载。

### 全局缓存清理

音频分析页面的 **清理音频缓存…** 或目录管理中的 **清理全部音频缓存…** 都会先显示确认框。确认后清理三套工具为**所有谱面**保存的分离结果、采音结果、安装下载缓存、推理缓存和临时文件，也检查已知运行环境目录中的遗留缓存。保留已下载模型、Python 环境、源码、谱面和原音乐；用户自行导入的声部也保留。当前会话恢复原音乐播放，移除派生分离音源，清除采音预览及内存中的分析缓存，需要时重新分离或采音。清理下载缓存后，后续更新环境可能需要重新下载安装包。

存在安装、分离或检测任务时拒绝清理；清理和迁移不能同时运行。仅处理明确的缓存子目录，不递归删除工具根目录，也不跟随指向其他目录的链接。被占用、发生变化或无权限的文件会保留并报告，不影响模型和原始谱面文件。

### 已有环境

展开 **分离选项与高级环境设置**：

- **重新检测**：检查当前环境是否可用。
- **选择已有环境**：选择已经安装 Demucs 4.1 的 Python 可执行文件，检查通过后使用。
- **用已有 Python 安装**：有 Python 3.10–3.12 时可手动指定基础解释器，编辑器仍在独立虚拟环境安装依赖。
- **清理分离结果缓存**：删除派生结果，保留模型和环境，原音乐与谱面不变。

自备环境的 Python 必须在更新编辑器后仍然存在。不要选择另一个软件解压目录中随时可能被删除的临时 Python。

## 网页端、手机和平板

目前网页端提供声部导入与后续分析，**不在浏览器内直接运行 Demucs，也没有自动上传音乐的云分离服务**。

最简单的流程：

1. 在 RPEN 桌面端打开相同音乐并完成分离。
2. 点击需要保留的声部右侧的 **导出**，保存 WAV。
3. 将 WAV 传到使用网页的设备。
4. 在网页端点 **导入声部**，可一次选择多个音频文件。
5. 勾选一个或多个声部，使用编辑器播放按钮播放，同时查看彩色波形/频谱或进行 AI 采音。

也可以使用已安装的 UVR、Demucs 或其他分离工具导出结果再导入。没有桌面电脑时，先通过另一设备或自行选择的工具获得声部文件；RPEN 不内置第三方云上传流程。

网页端不需要安装 Python。DDC、Mapperatorinator 等本机模型仍只通过桌面端启动；网页端的频谱分析和采音可以处理已导入声部。

## 对齐与保留结果

- 所有声部与原音乐共享起点和谱面延迟，不另设声部偏移。导入同一首完整音乐的分离结果，不要裁掉开头静音、变速或使用不同版本音乐。
- 较短的声部在结尾补静音，过长的部分不延长编辑器时间轴。声道或采样率不同的文件按原音乐时间轴重采样、混合，不移动音符或修改谱面延迟。
- 分离和勾选不会替换素材库中的原音乐。勾选会临时改变实际播放音源；退出谱面后恢复只播放原音频，选择不持久化。
- 声部列表属于当前音乐的分析会话，换音乐或重启后需要重新导入，或再次分离相同音乐以复用本机缓存。
- 再次分离成功后整组替换当前会话中所有 `kind:separated` 条目，不按模型追加；同模型或不同设备/参数重做也使用新结果。原音乐和 `kind:imported` 条目保留。同类试听声部按 stem 映射至新结果，不存在的声部移出，空选恢复原音乐；新结果、必要的解码及试听准备就绪后才切换。失败、取消或迟到的结果不改旧列表与播放选择。旧混音缓存失效，旧音高/采音预览按来源引用及修订失效。磁盘中的可复用分离缓存仍按原存储管理规则保留。
- 声部不写进谱面 PEZ。需要长期保留或在另一设备使用，请导出 WAV。
- 同一谱面内，近期使用的声部组合会缓存混音与播放准备结果，切回时复用；缓存按容量淘汰，退出谱面、更换音乐或移除相关声部后清理或失效，不写入谱面文件。
- 波形按每个显示行覆盖的完整时间区间取峰值，避免短音频滚动时因跳点采样而闪动，并复用多级峰值索引。波形/频谱只绘制有效区域，静止画面复用；定位、缩放、窗口大小、颜色或透明度变化时及时刷新，不降低可见范围的显示精度。

## 显著音高

音频分析页的“显著音高”支持一个分离或用户导入声部。音高目标与试听多选独立，不替换原音乐或改变当前混音；同一时间只保留一个目标声部和一种显示位置。切换目标取消过期结果，移除、替换目标或更换音乐后关闭。声部选择不跨音乐会话保存，显示位置与显示设置保存在本机的 `rpen-audio-pitch-view-v1`，旧音域/位置偏好保留，其余新增项使用默认值。

- 原位模式替代目标声部的波形/频谱栏；目标未勾选试听时临时增加该栏，其他已选声部保持原图。
- 右侧模式使用整个事件区宽度，作为事件下方的透明衬图，保持音符区波形/频谱。使用与原分析图相同的底层绘制关系，画布不命中鼠标；保留事件显示、选择、放置、删除、粘贴、拖动、多选控制球及快捷键，不清空选择、不产生撤销记录。仅音符编辑或其他专用编辑/预览模式暂时隐藏，恢复后继续显示。
- 时间纵向排列，与原音乐起点、META.offset、BPM、判定线倍率和滚动缩放统一映射。横向以 MIDI 半音间距排列，保留浮点音高和滑音；C 音提供音名标注。只有原位模式通过音符画布的非阻断悬停显示音名、频率、拍数；右侧模式不注册事件区的音高悬停监听，不改写事件画布原有提示。
- 显示设置默认折叠：`followWaveform:false`、`threshold:0.2`、`opacity:0.6`、`lineWidth:4`、`showGrid:true`；阈值范围 0.05–1、不透明度 0–1、线宽 1–10 CSS 像素。默认不按波形衰减；开启后不透明度乘以对应时间区间的归一化波形包络，再应用音频画布皮肤透明度。包络仅开启时计算并复用，关闭时取消计算并释放该图持有的包络，不增加模糊或发光绘制。
- 音域自动适配全曲默认有效候选；两端滑条显示音名、八度及 Hz，拖动进入手动模式并立即重绘，最小跨度为一个半音。范围外不绘制、悬停也不报告隐藏的音高。自动模式下控件值及时同步至实际显示范围，不显示与图形不同的旧默认值。
- 显示设置中的“重置设置”恢复默认阈值、不透明度、线宽、波形透明度开关、参考线及自动音域，保留当前声部与显示位置。原控件和折叠状态保留，重置即时重绘并持久保存；取消额外包络计算，不重新推理、不清空音高缓存、不创建谱面撤销记录。
- Basic Pitch 的复音候选压为单一显著音高，以短时连续性减少近似候选抖动；不确定、静音及无明确音高处留空，明显换音断开连线。保留置信度至少 5% 的候选供显示调参，默认只绘制至少 20%，保持旧默认连续性和八度修正条件；阈值越高只减少可见帧。算法缓存键升级为 `basic-pitch-1.0.1-dominant-v2`，旧结果首次需要重算，之后阈值/音域/透明度等调节均不重新推理。不是完整转谱或保证正确的主旋律提取。
- Basic Pitch 1.0.1、TensorFlow.js/WASM 4.22.0 随程序本地提供（Apache-2.0，详见 NOTICE 和 assets/vendor/basic-pitch）。仅开启时创建一个单线程 Worker，不使用渲染 GPU；可见时间附近优先，每块核心 4 秒、前后各 0.5 秒上下文，原音乐不整体复制或传出。每次推理释放临时张量，完成、取消、切源时终止 Worker。
- 当前最长支持 30 分钟；轨迹缓存最多 4 项且合计不超过 8 MiB，持久结果缓存最多 32 项且不超过 32 MiB，以完整音频内容、采样率、声道、算法/模型版本识别。桌面结果位于 `起音检测/cache/pitch-v1`，使用已有位置设置、迁移、清理与互斥协议；网页使用 `rpen-audio-pitch-v1` IndexedDB。缓存失败保留当前结果并提示，下次可能重新分析。
- 原位/右侧切换、绘制阈值、不透明度、线宽、参考线、音域、BPM、延迟及判定线倍率变化仅重绘，不重新推理。绘制只遍历可见时间段，静止图复用；关闭后没有推理或新增后台任务，不写入谱面与撤销历史。

## 遇到问题

| 表现 | 处理 |
| --- | --- |
| 下载失败 | 检查网络和磁盘空间，再点一键准备；安装详情可查看具体原因 |
| GPU 不可用 | 选择 CPU，或确认使用 NVIDIA 加速环境且驱动兼容 |
| 提示环境不完整 | 重新准备，或选择正确的已有 Demucs 4.1 环境 |
| 分离时间较长 | 留在页面等待，可取消；六声部与整首长音乐可能更慢 |
| 声部与音乐不同步 | 核对是否为同一首完整音乐，是否裁掉开头或另行变速；所有声部共用原音乐起点 |
| 只播放原音频 | 分离后勾选需要的声部，再取消原音频的勾选；至少保留一项 |

声部分离与采音检测是两个步骤。分离环境准备完成，不代表其他模型环境也已经安装；界面分别显示其状态。
# 谱面版本控制

“谱面工具 → 版本控制”打开右侧临时页面，包含提交图、更改、分支、储藏和引用日志。首次打开自动建立初始提交。已有项目会保存版本库标识，不要求为此修改谱面；新建或导入后尚未保存的谱面须先保存到谱面库，才能在重新打开时关联相同的历史。

## 快照和保存

一个快照包含谱面 JSON、素材字节、素材路径、空文件夹和谱面 JSON 文件名。文件按内容哈希去重。先“暂存”再“提交”可记录当前快照；分支、标签和提交图属于版本库，与编辑器撤销栈独立。提交历史不会自动覆盖谱面库，手动保存也不会自动生成版本提交。自动保存继续创建恢复副本。

检出、重置、合并或应用储藏会暂停播放并重新载入快照，结果标为未保存，仍需保存到谱面库。当前编辑会话与撤销栈会重新建立；模组应处理现有的 `editor:chart` 通知并刷新引用。软重置只移动版本库引用，混合重置还更新暂存区，硬重置另将快照载入编辑器。改动冲突、校验或写入失败时不应移动 HEAD 并提交损坏结果。

## 合并约定

使用共同祖先、当前分支与目标分支进行三路合并。单侧修改直接采用，独立字段修改组合，不能确定的修改显示“当前 / 对方”冲突选项。判定线优先按两侧唯一名称识别，再使用唯一的内容对应处理改名；重名且无法确定身份时要求选择整个谱面，避免猜测对应关系。互不相容的重排显式要求选择排列顺序。

父线和内置根级 shader 的线号会先转换为临时身份，待冲突选择、删线和顺序确定后再恢复最终编号。删除的父线解除绑定，删除所属线的 shader 不会改绑到其他线。临时身份只用于算法，不改变谱面结构，也不写入谱面文件。提交合并前检查谱面结构及父线索引、循环关系；产生循环时保留原分支，用户修改对应分支后重试。

谱面中未知字段与模组数据会保留，但通用 JSON 合并不能推断未知字段的含义。自定义线号引用、插件资源及字段间约束需要模组提供校验或自定义合并。接口接入和钩子范围见[模组协议](MOD-PROTOCOL.zh-CN.md#62-谱面版本控制)。

## 存储和备份

网页端历史位于当前站点的独立版本数据库。桌面端历史保存在所选原生谱面库的 `version-repos`、`version-commits`、`version-trees`、`version-blobs` 中，素材仍由谱面库按内容去重。桌面“备份完整库到文件夹”和搬迁包含这些记录；切换库也切换其版本历史。

普通 JSON、PEZ 和谱面库 PEZ 合集导出的是作品内容，不附带版本历史；需要单独迁移历史时，在版本控制页导出仓库包。网页端清除站点数据会同时清除本地版本历史，应保留仓库包或其他外部备份。

## 仓库包 v1

仓库包为 JSON，`format` 为 `rpe-next-chart-vcs`，`version` 为 `1`。根对象包含导出时间 `exportedAt`、版本库引用与配置 `repo`、提交数组 `commits`、树数组 `trees` 和二进制对象数组 `blobs`。每个二进制对象以 `[内容哈希, Base64字节]` 存储，树记录谱面对象哈希、素材对象列表、文件夹与谱面文件名；提交记录树、父提交、作者、时间、说明和操作种类。包内的项目作者名称、邮箱和所有可达历史素材会随包导出。

导入校验二进制和树的内容哈希、必要引用及已有对象的一致性，不覆盖内容不同的同名对象。导入到当前仓库时重建提交身份，重名分支和标签生成独立名称；导入不会自动检出或覆盖当前编辑。此格式是版本控制数据，不是谱面格式，不通过修改 `RPEVersion` 表达。

规范化、差异、合并和内容校验保留 JSON 的所有自有字段，包括 `__proto__`、`constructor`、`prototype` 等名称；这些名称始终作为数据处理。冲突路径只遍历自有属性，写入与删除不会访问原型链；分支和标签名称也遵循相同的自有属性规则。

## 皮肤入口

编辑器皮肤可用 `@version-control-tool` 重排入口，用 `@version-control-panel` 设置面板样式；页面名为 `version-control`，可通过 `data-rpen-pane` 定位状态。这是皮肤 API 3 的兼容扩展，原有皮肤继续有效。
# RPEN 编辑器皮肤协议 v1

AI辅助沿用API3，新增 `@ai-tool`、`@ai-panel`、`@tab-ai` 与页面名 `ai`。入口可参与organize，页签仅在本次谱面首次开启后常驻；不得改变应用控制的显隐规则或妨碍审批与停止按钮。

AI发送栏的 `.agent-route-toggle` 将模型与推理档位合并显示，`.agent-route-menu` 为点击后浮动展开的设置面板，支持原生Popover顶层显示；样式调整应保留其浮动定位、自动收起与键盘关闭行为，不将其展开为常驻内容。

模组管理界面提供 `@mods-open/@mod-manager/@mod-list/@mod-details/@mod-status/@mod-warning` 别名，沿用 API 3。模组入口可参与 organize；皮肤不会改变外部模组导入的确认流程。

本文同时是皮肤作者的实现规范和 AI agent 的制作指南。协议标识为 `rpen-editor-skin`，协议版本为整数 `1`。编辑器皮肤管理位于 **设置 → 编辑器皮肤**，适用于网页端和桌面端。

当前界面契约版本为 **API 3**。旧的 v1 清单继续有效；使用 API 2 能力（响应式规则、参数、变体等）的皮肤应声明 `"compatibility":{"minApi":2}`，在画布色板中引用参数（API 3）的皮肤应声明 `"minApi":3`。API 版本针对编辑器皮肤接口，与应用版本、皮肤自身版本和文件协议 version 各自独立。

兼容增加 `@note-tracking-tool`、`@note-tracking-panel` 和 `@agent-images`。音符追踪页面名为 `note-tracking`，属于从谱面工具打开的临时页面；墨线将入口放入生成组。Agent 图片使用 `.agent-image-list/.agent-image-card/.agent-image-open/.agent-image-remove`，保留缩略图的可辨识性、移除按钮和放大预览，不加载远程 Markdown 图片。横向间距设置的字段为 `note-spacing`，只改变音符坐标映射，不影响资源包贴图尺寸。`notes-only-note-scale` 仅缩放单线仅音符视图中的音符视觉宽高，默认 0.9，不改变坐标映射。

右键默认值设置增加 `@placement-defaults-menu`（入口）及 `@placement-defaults`（浮动面板）。面板包含 `.placement-defaults-tabs` 的 `role=tab` 按钮、`.placement-defaults-body` 与 `.placement-defaults-reset`；当前页签通过 `aria-selected=true` 标识，输入控件以 `data-rpen-field` 标识属性。颜色、判定颜色和打击音效复用音符属性控件。应保留两个页签、重置和关闭的可用性，并允许内容在窗口高度不足时滚动。

谱面检查增加 `@diagnostics-panel`、`@diagnose-deep`、`@diagnose-target`。`.diagnose-actions` 放置目标格式和深度检查/取消按钮，`.diagnose-state` 显示后台进度，`.diagnose-item[data-diagnostic-code]` 标识检查类型。结果按严重性和物件类别分组、分批展开；不要把“显示更多”或深度检查的进行中状态隐藏。检查不得由皮肤动画或重新布局自动触发。

物件类别下的 `.diagnose-type[data-diagnostic-type]` 按具体问题类型再次分组，折叠状态会保留。定位时检查面板继续显示，左侧使用 `.diagnostic-highlight` SVG 覆盖层临时描出目标物件，`.diagnostic-highlight-outline` 的虚线沿边移动约数秒；覆盖层无指针事件，不应改变其相对 stage 的定位或尺寸，也不应让其影响画布布局。动画只更新该覆盖层，不触发谱面画布重绘。报错文案显示实际检测值，不重复显示规则阈值。

直接放置沿用 API 3，新增 `@direct-placement-toggle`（工具栏开关）、`@direct-placement-close`（退出按钮）、`@direct-placement`（预览中的裁剪容器）、`@direct-placement-surface`（旋转编辑面）与 `@preview-line-picker`（重合线列表）。开启后原 `#notes` 画布临时移入编辑面，继续沿用 `notes` 画布色板，关闭后放回原位；皮肤应按画布自身定位，不依赖父元素层级，不覆盖编辑面或画布运行时管理的位置、尺寸和 transform。重合线列表的每项只显示线号与 alpha，保留应用控制的显隐。

工具栏开关显示“直接放置音符”，右侧退出按钮显示“× 放置”。展开区的背景和网格不透明度由应用设置控制（默认 0.5），编辑音符与控制点不随背景变淡；不要对整个编辑面或画布加 opacity 来实现背景透明。应用将预览音符临时降至 30%，退出后恢复。上下双区沿判定线汇合并独立裁剪，位置偏差的对应音符用细虚线连接；此映射由编辑器维护，皮肤不要覆盖画布 transform。工具栏提供只读布局变量 `--rpen-placement-align-gap`，表示放置控件与上方拍数控件左端对齐所需的 margin-left；墨线采用此变量，并保留最小间距。窗口或控件尺寸变化时更新，空间不足时保留控件之间的间距。

本文描述已经实现的能力。结构校验参见 [`schemas/editor-skin-v1.schema.json`](../schemas/editor-skin-v1.schema.json)，组件、变量及静态控件清单参见 [`schemas/editor-skin-components.v1.json`](../schemas/editor-skin-components.v1.json)。最终导入还会进行文件、引用、CSS、图片和字体校验；只通过 JSON Schema 不代表包一定有效。

## 1. 范围与设计原则

皮肤可以改变整个编辑器的表面、文字、尺寸、间距、控件样式、布局、可移动命令的分组、图标、装饰、字体和动画，也可以为编辑时间轴、框选层、剪贴板及切线缩略图调整画布颜色与字体。可以制作亮色、暗色、高对比、紧凑、宽松、侧边命令栏等不同外观。

皮肤不改变音符、事件、噪域的语义，不写入谱面，不调整热键，不添加可执行脚本，不改变预览中判定线、音符、噪域、shader 或素材本身的颜色与外观。噪域皮肤仍使用独立协议。工具按钮上的图片可以替换；播放预览中的音符图片不在此协议范围。

界面的原始功能节点仍由应用拥有，皮肤操作的是这些节点的呈现。`organize` 可以移动列入白名单的命令按钮，其原有事件和禁用状态保留。其他组件可以通过 CSS 的 flex/grid/order 等重排，也可以通过 `hide` 从界面隐藏控件；隐藏后不占位，内部节点继续存在。v1 不允许任意添加 HTML、替换表单、销毁功能节点或将画布重新挂接到另一个父节点。

没有自定义皮肤时直接使用编辑器现有样式，不加载皮肤基础覆盖层。缺省皮肤不是一个导入包，其保留标识为 `default`。本版本另外内置“墨线 Inkline(cmdysj)”和“RPE Classic · 经典编辑器”，可直接在设置中选择。

RPE Classic 的静态皮肤与配套 `rpe-classic-layout` 模组随本体配套分发。选择该皮肤自动加载对应布局，切换其他皮肤卸载布局补丁与监听；安全模式或手动停用模组时保留墨线回退。两者版本必须一致，导入包不能覆盖内置版本，更新随本体分发。RPE Classic 后续界面适配由该皮肤维护方验证，不纳入每轮本体 UI 回归。未选用时只登记轻量元数据，不读取该皮肤的完整样式、贴图和模组代码。

内置资源索引可使用 `deferred`、`metadata` 和 `shared` 实现延迟读取和重复资源复用；这些仅属于宿主内置目录，不是 `.rpenskin` 协议新增字段。导出时会恢复完整的包内文件，导出的皮肤仍可单独导入，字体与许可不会丢失。

扩展包根目录还允许携带 README.md、ASSETS.md、NOTICE（可带 .txt/.md）和 LICENSE（可带许可证名后缀及 .txt/.md），用于保留说明与许可。其他未声明素材仍会拒绝，文档不作为样式或代码执行。

### 1.1 当前限制概览

| 范围 | 当前边界 | 原因 / 替代方式 |
| --- | --- | --- |
| 功能与数据 | 不执行脚本、不修改谱面数据、热键和编辑算法 | 皮肤负责呈现，功能扩展由应用实现 |
| 控件结构 | 可以隐藏、重排；不能销毁功能节点或用任意 HTML 替换表单 | 现有应用会直接读取这些节点及其值；使用 hide 不会破坏引用 |
| 跨容器移动 | organize 支持命令、工具、页签和指定组合控件，目标为八个容器 | 输入标签成组移动；取样、画布、页面正文不任意换父级 |
| 绘制 | 每类画布可以有独立色板、透明度、线宽、虚线和字体，尚非每个图形都有独立语义变量 | 同一画布中共用源色仍共用映射；图片像素、音符贴图及播放渲染不改变 |
| 动画与素材 | CSS 动画、动态图片、字体；不支持视频、音频、Lottie 或活动 SVG | 支持包内素材、有限内置图标和高 DPI 来源，不引用任意远程资源 |
| 样式语法 | 声明式 CSS；支持 media/container/supports/starting-style/property | 不能导入 raw CSS 或脚本，important 只开放外观及排列属性；显示逻辑和恢复入口保留 |
| 资源与数量 | 总包 32 MiB、单文件 12 MiB、最多 512 个文件等 | 防止解压和解码成本失控，完整上限见第 11 节 |

这里的“不能销毁节点”来自当前 UI 与功能代码的耦合，不是隐藏控件的限制。例如应用刷新时仍会查询保存按钮、时间输入框或画布；直接删除会让查询返回空值或破坏坐标关系。hide 保留这些节点，不改其输入值、应用隐藏状态或事件绑定，只从皮肤的界面呈现中移除它们。

## 2. 包结构与最小样例

`.rpenskin` 是 UTF-8 文件名的普通 ZIP，也接受 `.zip` 或导入文件夹。支持 ZIP Stored、Deflate，不支持加密、分卷、ZIP64。推荐将 `skin.json` 直接放在根目录，也接受一个共同的外层文件夹。外层文件夹之外不能有其他文件。

```text
my-skin/
  skin.json
  images/
    save.svg
    panel.webp
  fonts/
    ui.woff2
```

包中只能有 `skin.json` 和 `assets` 显式声明的素材，不要附带 README、系统隐藏文件或源码。许可声明可写入 license 字段并在包外提供完整许可；字体和图片的再分发权由作者确认，不能省略其许可证要求的声明。

仅需一个文件即可构成皮肤：

```json
{
  "$schema": "../../schemas/editor-skin-v1.schema.json",
  "protocol": "rpen-editor-skin",
  "version": 1,
  "id": "paper-example",
  "name": "纸面",
  "author": "Your name",
  "colorScheme": "light",
  "tokens": {
    "background": "#eef2f7",
    "surface": "#ffffff",
    "surface-alt": "#f2f5fa",
    "elevated": "#ffffff",
    "input": "#ffffff",
    "text": "#243347",
    "muted": "#526680",
    "border": "#bccbde",
    "accent": "#286bd1",
    "accent-text": "#154a99",
    "selected": "#e2edff"
  },
  "styles": [
    { "selector": "@header", "set": { "border-bottom": "1px solid #bccbde" } }
  ]
}
```

`$schema` 仅供编写工具使用，编辑器不会请求它，不需将 schema 放进皮肤包。这里的相对路径需按作者的目录调整。

### 2.1 清单顶层字段

| 字段 | 类型 / 默认 | 作用 |
| --- | --- | --- |
| `protocol` | 必填字符串 | 固定 `rpen-editor-skin` |
| `version` | 必填整数 | 固定 `1`，不是应用版本 |
| `id` | 必填字符串 | 稳定标识，见下文；同 id 导入会询问是否替换 |
| `name` | 必填，1–80 字符 | 显示名称；也可写成 `{ "zh-CN": "…", "en-US": "…" }` |
| `author` | 可选，1–100 字符 | 在名称后以括号显示 |
| `description` | 可选，1–2000 字符 | 设置中显示的说明；同样支持多语言映射 |
| `colorScheme` | `dark` | `light` 或 `dark`，影响浏览器原生控件 |
| `assets` | `{}` | 图片和字体注册表 |
| `tokens` | `{}` | 基础设计变量，未填写时使用下表缺省值 |
| `styles` | `[]` | 按顺序应用的声明式 CSS 规则 |
| `motions` | `{}` | 命名关键帧动画 |
| `organize` | `[]` | 命令分组和移动 |
| `hide` | `[]` | 隐藏指定控件，不占位，不销毁功能节点 |
| `texts` | `[]` | 界面文字、提示和无障碍名称覆盖 |
| `icons` | `{}` | 组件别名到图片素材 id 的映射 |
| `decorations` | `[]` | 无交互的装饰图片 |
| `canvas` | `{}` | 编辑器画布的色板和字体 |
| `skinVersion` | 可选字符串，最多 40 字符 | 皮肤自身版本，建议采用 `1.0.0` 形式 |
| `compatibility` | `{}` | minApi/maxApi，正整数，检查当前 API 是否在闭区间内 |
| `preview` | 可选 image 素材 id | 设置中的预览图 |
| `license` | 可选字符串，最多 4000 字符 | 许可名称/声明，显示在设置说明中 |
| `parameters` | `{}` | 用户可调的颜色、数值、开关、选择参数 |
| `variants` / `systemVariants` | `{}` / 未设置 | 同包变体及系统明暗映射 |
| `properties` | `{}` | 受限的 CSS 自定义属性注册，用于可插值动画 |

标识（清单 id、素材 id、动画 id、分组 id、装饰 id、变量名）采用 `^[a-z][a-z0-9-]{0,63}$`，例如 `paper-blue`。皮肤 id 不能为 `default`。名称、说明等支持 Unicode。字符串不得只有空白。未知字段会忽略，建议元数据扩展使用 `x-` 前缀；未知协议版本拒绝导入，不能借扩展字段引入脚本或额外文件。

文件路径必须为包内相对路径，用 `/` 分隔，最多 240 字符。禁止绝对路径、盘符、反斜杠、空路径段、`.`、`..`、控制字符、`?`、`#`；文件名大小写冲突会被拒绝。文件名可以包含汉字或空格，推荐使用便于跨平台传输的英文文件名。

## 3. 设计变量 tokens

清单中的 `tokens.surface` 被编译为 `--rpen-surface`，CSS 中使用 `var(--rpen-surface)`。所有变量值都是 CSS 字符串，包括数值。变量不是表达式脚本。

| 变量 | 缺省值 | 自动作用范围 |
| --- | --- | --- |
| `background` | `#303030` | 页面与图片预览底色 |
| `surface` | `#303030` | 主工作台、右侧面板、窗口 |
| `surface-alt` | `#282828` | 工具栏、列表卡片、分组、辅助栏 |
| `elevated` | `#202020` | 顶栏、播放栏、通知、底栏 |
| `input` | `#383838` | 输入框、选择器、普通按钮 |
| `hover` | `#505050` | 普通按钮悬停 |
| `text` | `#f0f0f0` | 正文、标题、控件和标签 |
| `muted` | `#aaaaaa` | 提示、次要信息、小字 |
| `border` | `#666666` | 普通边框 |
| `border-strong` | `#888888` | 悬停强调边框 |
| `accent` | `#ffdc70` | 焦点轮廓、强调、范围/勾选控件 |
| `accent-text` | `#ffe49b` | 选中按钮文字 |
| `selected` | `#4d4632` | 选中按钮、列表项底色 |
| `selected-border` | `#aa9251` | 选中边框 |
| `success` | `#65c878` | 成功通知边框 |
| `warning` | `#e6c65c` | 警告通知和属性提示 |
| `error` | `#e46e6e` | 错误文字与边框 |
| `info` | `#8dd6ee` | 分组名等信息文字 |
| `radius` | `1px` | 普通控件圆角 |
| `radius-panel` | `4px` | 窗口和弹出层圆角 |
| `font-family` | `RPE, "Microsoft YaHei", sans-serif` | DOM 界面字体；可用 `font(id)` |
| `font-size` | `13px` | 根字号，已有专用字号需 styles 单独调整 |
| `control-height` | `29px` | 文件栏、操作网格、窗口和皮肤管理按钮的最小高度 |
| `control-padding` | `6px 10px` | 上述普通命令按钮内边距；微型按钮保留专用几何 |
| `gap` | `6px` | organize 创建的分组间距，其他容器可在 styles 引用 |
| `inspector-width` | `29.7%` | 宽屏右侧面板宽度，下限 240px；窄屏使用原有响应布局 |
| `panel-shadow` | `0 4px 16px #0005` | 窗口、菜单、通知阴影 |
| `motion-fast` | `120ms` | 普通按钮的颜色和边框过渡 |
| `motion-normal` | `220ms` | 供皮肤自定义动画引用 |
| `motion-easing` | `ease` | 普通按钮过渡缓动，也可自行引用 |
| `icon-filter` | `none` | 既有单色伪元素图标及静音图标的滤镜 |
| `scrollbar-thumb` | `#777777` | 滚动条颜色 |

基础变量是覆盖入口，不保证每一处历史专用颜色都能仅靠一个变量改变。精细主题应继续通过组件规则调整。允许额外的合法 token（例如 `card-gap`，对应 `--rpen-card-gap`）；只定义它不会自动产生新行为。`styles.set` 中可声明 `--skin-*` 私有变量，也可覆盖 `--rpen-*`。应用的 `--accent`、`--muted`、`--line` 在根与编辑/右侧区域桥接为皮肤的 accent、muted、border。

tokens 是初始默认值，不是只能读取的常量。可在 `@root` 状态/媒体规则中覆盖全局变量，在 `@inspector` 等子树中覆盖局部变量。原生控件明暗由 CSS 的 `color-scheme` 属性决定，同样可以在规则中改变，不限于顶层 colorScheme。

不要通过 CSS 改写 `--icon` 绕过资源管理，请使用 `icons` 或 `asset(id)`。多选控制球的语义颜色保留在 `--ball-color`；改变大小、边框或阴影时，应保留红/绿/蓝的可区分性。

## 4. 组件与界面组织

选择器中的 `@名称` 会展开成下列稳定组件选择器。使用自定义皮肤期间，匹配的元素还会有 `data-ui="名称"` 标记。动态页面创建后会补上标记；同一节点可能匹配多个别名，所以**推荐直接用 `@别名`，不依赖 data-ui 的最后取值**。

| 别名 | 组件 / 实际选择器 |
| --- | --- |
| `app` | `body`，整个应用 |
| `header` / `brand` | `header` / `.brand` |
| `document-name` / `file-actions` | `#document-name` / `header nav` |
| `transport` / `transport-actions` | `.transport` / `.transport-group` |
| `workspace` / `editor` | `.workspace` / `.editor` |
| `toolbar` / `tools` / `view-controls` | `.editor-toolbar` / `.tools` / `.view-controls-inline` |
| `timeline-header` / `stage` | `.timeline-head` / `.stage` |
| `editor-actions` | `.editor-footer` |
| `inspector` / `inspector-tabs` | `.inspector` / `.inspector-tabs` |
| `chart-tools` | `[data-panel="chart"] .action-grid` |
| `project-home` / `project-list` | `#home` / `#project-cards` |
| `footer` / `status` | `body > footer` / `#status` |
| `notifications` | `#notifications` |
| `dialog` / `settings` / `settings-body` | `#modal` / `#settings-modal` / `.settings-body` |
| `settings-header` / `settings-navigation` / `settings-navigation-item` / `settings-search` | 设置页头、左侧分类导航、分类链接、搜索框；当前分类链接带 `aria-current="location"`，滚动与点击同步 |
| `settings-category` / `settings-card` | 连续滚动的分类区块、原设置分组；分类用 `data-settings-section` 标识，值为 `general`、`appearance`、`editor`、`preview`、`audio`、`input`、`storage`、`compatibility`、`about`。搜索仅临时隐藏未匹配分组，不移除控件及状态 |
| `about-settings` / `app-version` / `app-update-badge` | 关于设置卡片、底栏版本按钮、新版本文字标记；版本按钮在发现新版时具有 `has-update` 类，标记单独使用 `--rpen-info` 颜色，点击定位到关于页 |
| `update-progress` / `update-notes` / `update-dialog` | 原生下载进度条、默认折叠的更新日志、下载完成及安装确认对话框；进度用 `value/max` 表达，不确定时移除 `value`。皮肤仅改变呈现，不改写下载地址、校验、权限或安装过程 |
| `update-release-dialog` / `update-release-content` | 成功更新后首次进入的独立更新日志窗口和滚动正文。标题包含实际安装的版本；显示后即记录为已展示，普通重启不会再次弹出。关于页的折叠日志标题同样包含对应版本 |
| `language-settings` / `language-select` | `#language-settings` / `#ui-language`，语言分类与选择控件 |
| `dictation-settings` / `dictation-indicator` / `dictation-candidate` / `dictation-permission` | 本地语音输入设置、按住说话状态浮层、可复制结果、麦克风授权与系统权限说明面板；听写状态浮层不改变当前输入焦点 |
| `performance-monitor` | 默认 F10 开关的性能浮层；位于浏览器顶层，支持拖拽并记住位置。内部用 Shadow DOM 保持深色半透明面板的可读性，皮肤可调整宿主样式，不移动或复制内部数值及图表节点 |
| `graphics-settings` / `graphics-warning` | Windows 桌面端“图形设备”设置和启动显卡提示。显示实际渲染器，保留独显偏好、检测、系统设置、复制程序路径及“不再提示”交互；网页版不显示 |
| `theme-settings` | `#editor-skin-settings` |
| `context-menu` | `.timeline-context-menu` |
| `speed-curve-menu` / `speed-curve-panel` | 单音符右键“调速曲线”入口与按需创建的浮动面板；保留模式按钮、节点数值、横向范围和纵向缩放控件。仅选中节点显示紧凑属性标签，其他节点保留图形标记；状态消息留在底部，不覆盖曲线。绘图区内沿用 Tap 放置快捷键直接添加节点，面板内删除沿用普通删除/快速删除的快捷键配置 |
| `line-overview` | `.line-switcher`，Ctrl+滚轮线缩略图 |
| `clipboard-history` | `#clipboard-results` |
| `version-control-tool` / `version-control-panel` | 谱面版本控制入口按钮 / 右侧版本控制页面根节点 |
| `root` | 文档根；可附加状态属性及伪类 |
| `line-controls` / `beat-controls` | 线号组合 / 拍数输入组合 |
| `offset-control` / `rate-control` / `pitch-control` | 延迟 / 倍速 / 保调标签及其控件 |
| `view-buttons` / `multi-line-controls` | 视图按钮组 / 多线头栏按钮组 |
| `time-progress` | 横向时间滑条及标记整体 |
| `time-readouts` | 当前秒数、总时长与当前拍数的组合，可整体重排 |
| `note-skin-settings` / `note-skins-open` / `note-skin-manager` / `note-skin-gallery` | 音符皮肤设置入口区域 / 管理按钮 / 独立管理界面 / 皮肤卡片列表；管理界面保留图片预览本色，不经过 Canvas 色板换色 |
| `clock` / `beat-display` / `bpm-display` | 当前秒数与总时长 / 当前拍数 / 当前 BPM 读数，可分别设置样式或隐藏 |
| `note-properties` / `event-properties` / `line-properties` / `noise-properties` | 四类属性表单 |
| `noise-layers` / `noise-list` / `line-list` / `multi-line-list` | 对应层/物件列表 |
| `multi-line-event-columns` | 多线列表上方默认折叠的事件栏勾选组；内部 `.multi-line-event-options` 自动换行，保留原生勾选交互 |
| `asset-tree` / `asset-details` | 素材树 / 素材详情 |
| `sample-bar` / `sample-panel` | 预览取样操作条 / 原地取样面板 |
| `field` / `hint` / `panel-title` / `panel-actions` | 字段行 / 提示 / 标题 / 页面操作区 |
| `batch-controls` / `batch-ball` | 多选控制球整体 / 单个控制球 |
| `chat` / `peer-markers` | 联机聊天框 / 他人时间位置 |
| `tab-notes` / `tab-events` / `tab-lines` / `tab-chart` / `tab-noise` | 对应右侧页签，移动后别名仍有效 |
| `tool-select` / `tool-tap` / `tool-hold` / `tool-flick` / `tool-drag` | 选择与各类音符工具 |

调速面板中的 `.speed-curve-y-control` 与曲线区域等高；`.speed-curve-y-zoom` 是真正的竖向范围控件，应沿绘图区完整高度显示，不能套用横向滑条的固定高度或轨道样式。工具栏 `.speed-curve-snap-step` 是独立的纵轴吸附步长数值框，不能隐藏或被挤出面板。“后段缓动”直接描述当前节点到下一个同层节点的距离曲线；默认判定锚点坐标不可改，但用户节点重合时优先编辑真实节点，拍数输入、拖拽和删除保持可用，只有距离受判定约束而禁用。末节点缓动为原生 `disabled`，保留灰显和原因提示。近似识别的缓动编号以 ≈ 标注。面板位置、尺寸和视图设置自动记忆，皮肤不得覆盖用户保存的位置和大小。

以下命令的别名均直接展开为同名 id，例如 `@save` → `#save`：

| 范围 | 别名 |
| --- | --- |
| 文件 | `new`, `open`, `save`, `export`, `library`, `migrate`, `recover`, `preferences`, `help` |
| 播放 | `play`, `rewind`, `view-toggle`, `seek` |
| 编辑 | `undo`, `redo`, `copy`, `cut`, `paste`, `mirror`, `delete` |
| 视图 | `notes-only`, `game-ui`, `reset-camera`, `mute-current-line` |
| 谱面工具 | `metadata`, `bpm`, `assets`, `audio-analysis-tool`, `noise-areas-tool`, `curve-notes`, `curve-trajectory`, `text-lines-tool`, `noise-fit-tool`, `multi-line-tool`, `diagnose`, `history-panel`, `collaboration-tool` |

### 4.1 右侧页面与动态控件

右侧页面用 `[data-panel="页面名"]` 定位，用 `:not([hidden])` 区分当前显示。页面枚举如下：

| 页面名 | 内容 / 内容根 |
| --- | --- |
| `notes` | 音符属性，`#properties` |
| `events` | 判定线事件，`#event-properties` |
| `lines` | 判定线及分组，`#line-panel` |
| `chart` | 谱面工具 |
| `assets` | 素材库，`#asset-library` |
| `collaboration` | 联机，`#collaboration-panel` |
| `audio-analysis` | 音频分析，`#audio-analysis-panel` |
| `multi` | 多音符/多事件，`#multi-editor` |
| `multi-line` | 多线，`#multi-line-editor` |
| `metadata` | 谱面信息，`#metadata-editor` |
| `bpm` | BPM，`#bpm-editor` |
| `trajectory` | 曲线轨迹，`#trajectory-editor` |
| `spatial` | 空间轨迹右侧面板，`#spatial-editor`（`@spatial-panel`）；入口为 `@spatial-tool` |

`@sampling-controls` 对应普通事件、噪域及空间轨迹共用的取样设置区。取样期间设置停留在右侧，不覆盖预览；空间轨迹曲线使用谱面颜色，编辑器皮肤不重映射其画布颜色。
| `text-lines` | 文字拼合，`#text-lines-editor` |
| `noise-fit` | 噪域图案，`#noise-fit-editor` |
| `curve` | 曲线音符，`#curve-editor` |
| `diagnose` | 检查，`#diagnose-results` |
| `history` | 编辑历史，`#history-results` |
| `noise` | 噪域列表/层，`#noise-panel` |
| `noise-properties` | 噪域及内部事件属性，`#noise-properties` |
| `clipboard` | 剪贴板历史 |

`@sampling-controls` 对应普通事件、噪域及空间轨迹共用的取样设置区。取样期间设置停留在右侧，不覆盖预览；空间轨迹曲线使用谱面颜色，编辑器皮肤不重映射其画布颜色。

常见样式入口：`.panel-title` 标题、`.field` 标签/控件行、`.hint` 提示、`.action-grid` 操作网格、`.primary` 主操作、`.wide-button` 整行按钮、`details > summary` 折叠头、`.modal-actions` 窗口底栏。例如 `[data-panel="events"] .field input` 只修改事件输入框。不要将 CSS 绑定到某一行索引或中文标签文本；可参考组件目录中的静态 id，动态字段以所属面板加控件类型作通用定制。

音符属性字段与普通事件的首尾等输入提供 `data-rpen-field`，采用数据字段名，如 `positionX`、`startTime`、`start`、`end`；设置字段采用其控件 id。使用 data-key 的轨迹等工具也会映射同名字段。示例：`@note-properties input[data-rpen-field=positionX]`。没有显式登记此属性的历史表单不能按它定位，请使用对应稳定组件别名，不能用翻译后的 aria-label 充当字段契约。

音频分析的“显著音高”使用按需创建的 `#audio-pitch-overlay`，通过 `data-skin-canvas="audio"` 复用既有音频画布色板、字体及透明度参数。原位与右侧模式均为编辑画布下方的透明衬图，使用 `pointer-events:none`，不遮挡或接管编辑操作；`#audio-pitch-source`、`#audio-pitch-position` 分别为单声部选择及显示位置控件，`.audio-pitch-panel`、`.audio-pitch-options`、`.audio-pitch-status` 可用于界面样式。未开启时不创建音高画布或推理 Worker。
音高额外显示设置统一放在默认折叠的 `.audio-pitch-options`，阈值/不透明度/粗细滑条为 `#audio-pitch-threshold`、`#audio-pitch-opacity`、`#audio-pitch-lineWidth`，波形透明度与参考线开关为 `#audio-pitch-followWaveform`、`#audio-pitch-showGrid`。音域使用 `#audio-pitch-auto-range`、`#audio-pitch-low`、`#audio-pitch-high`，滑条旁的 `output` 显示音名和频率，`.audio-pitch-slider-control` 管理轨道及读数布局。上述调节不改变控件焦点、谱面数据或撤销记录。
`#audio-pitch-reset` 为显示设置内的重置按钮，保留当前声部、显示位置、控件及折叠状态，只恢复显示参数及自动音域。事件编辑区不提供音高悬停提示；原位模式的提示仍使用音符画布，衬图始终不命中鼠标。

本文登记的别名、面板名、变量、画布角色、状态属性与已经明确标注的字段名在同一 API 内保留意义；底层 class/id 可以调整，别名会同步适配。未登记的实现 class/id 不作此承诺。清单可用 compatibility.maxApi 限制未经作者验证的后续 API。旧运行时曾忽略未知字段，不能指望这些历史构建识别 API 2 的兼容声明；发布时请同时标注需要支持 API 2 的编辑器。

列表入口包括 `.line-entry`、`.line-group`、`.multi-line-row`、`.multi-line-group`、`.asset-tree`、`.asset-folder`、`.asset-row`、`.clipboard-card`、`.project-card`、`.noise-layer-card`、`.history-results`。取样入口包括 `.noise-sample-bar`、`.event-sample-bar`、`.event-sampler`、`.alpha-sample-gradient`；保持取样控制点、透明度渐变和颜色选择器的可辨识性。

### 4.2 模式、状态与布局约束

`.editor.notes-only`、`.editor.multi-notes`、`.editor.multi-events`、`.editor.event-sampling` 是现有模式类；其他模式状态可结合静态目录与源码查看。`button.active`、`:disabled`、`:hover`、`:focus-visible`、`:checked`、`[aria-expanded=true]`、`[aria-pressed=true]` 和 `#play[data-playing=true]` 可用于状态样式。`:has(...)` 可以按当前页面变化调整父容器。

布局可以改变整体网格比例、面板所在方向、控件尺寸和视图中的排列，但必须保留 `.stage` 及画布之间的相对定位、叠层和指针关系。不要改变 canvas 自身的 transform、CSS 宽高比或为它添加内边距；这可能破坏命中与坐标映射。可以改变包含它的编辑区域尺寸，由应用重新计算绘制尺寸。请保留多线滑条、间隔、取样隐藏、播放预览覆盖和 `[hidden]` 的行为。

含固定底部操作区的页面采用“滚动正文 + 不收缩底栏”，如 `.trajectory-scroll` / `.trajectory-footer`、`.text-lines-scroll` / `.text-lines-footer`、`.noise-fit-scroll` / `.noise-fit-footer`。主题可以重设布局，但要继续使用 `min-height:0`、`min-width:0` 和正确的 overflow，使生成/应用按钮在小窗口中仍能触达。

### 4.3 organize：重组现有命令

```json
{
  "organize": [
    {
      "slot": "file-actions",
      "id": "project",
      "label": "项目",
      "direction": "row",
      "collapsible": false,
      "items": ["new", "open", "save", "export"]
    }
  ],
  "styles": [
    { "selector": "[data-skin-group=project]", "set": { "gap": "8px", "order": "-1" } }
  ]
}
```

允许目标容器：`file-actions` 文件栏、`transport-actions` 播放按钮组、`editor-actions` 编辑底栏、`chart-tools` 谱面工具网格、`toolbar` 工具栏、`inspector-tabs` 右侧页签栏、`timeline-header` 编辑头栏、`footer` 底部状态栏。每个条目指定 `slot` 和 `items`。`id` 可选：填写时创建 `.skin-control-group[data-skin-group=id]`，未填写时直接追加到 slot。`direction` 默认 row，也可 column。`label` 为分组名；`collapsible:true` 需要 label，并使用默认展开的 details/summary。指定 direction、label 或 collapsible 时必须提供 id。分组 display、flex-direction 和 gap 由低优先级基础 CSS 提供，示例中的 gap 覆盖可以正常生效。

分组和未分组命令按清单顺序追加在目标末尾，未列出的原命令留在原处。可用 `order` 改变分组在 flex/grid 中的次序。单个命令只能在整个 organize 中出现一次，分组 id 不能重复；最多 40 个条目。暂时不存在的动态命令会在其创建后移动，丢失的命令不会被皮肤制造出来。

可移动命令白名单：

```text
new open save export library migrate recover preferences help
play rewind view-toggle
undo redo copy cut paste mirror delete
metadata bpm assets audio-analysis-tool noise-areas-tool
curve-notes curve-trajectory text-lines-tool noise-fit-tool noise-tracking-tool
multi-line-tool diagnose history-panel collaboration-tool version-control-tool
seek notes-only game-ui reset-camera mute-current-line
tools view-controls view-buttons line-controls beat-controls
offset-control rate-control pitch-control time-readouts multi-line-controls
tab-notes tab-events tab-lines tab-chart tab-noise
tool-select tool-tap tool-hold tool-flick tool-drag
```

时间、线号、视图参数按上表的组合容器移动，保留标签与输入的关系，不拆出其内部单个 input。取样控件、画布和页面正文不在移动名单内。移动后原父级选择器不再适用，请使用组件别名或对应数据属性。目标栏的原始 grid/flex 会保留，作者应为新组合设置明确的布局并验证模式切换；编辑器不会凭空创建命令副本。折叠命令组应保证重要操作还有可发现的入口。

`@clock` 显示“当前时刻s/总时长s”，当前时刻沿用谱面秒数、总时长为音频长度，均保留两位小数；`@beat-display` 另显示当前拍数（两位小数），不会替换用于定位的 `@beat-controls` 输入框。拍数依据当前编辑时间与 BPM 映射，普通编辑沿用当前线的 BPM 倍率，噪域编辑采用全局拍数。可用 `@time-readouts` 整体移动这两个读数，或分别用 styles/hide 调整；动态读数由应用更新，不应用 texts 写入固定文案。这些入口是 API 3 的兼容扩展，已有皮肤不需要提高协议版本。

当前秒数与总时长以“当前时刻s/总时长s”连续显示，作为整体与拍数读数分别占固定槽位并靠右对齐，位数变化不会改变相邻读数的位置；任一槽位不足时，全部读数按同一比例缩小并保留各自的右端位置。皮肤可调整 `@time-readouts` 的宽度与字体；请保留 `@clock`、`@beat-display` 内的数值节点，数值更新与自适应缩放由编辑器处理。时间滑条在自身容器中竖直居中，上方仍为时间标记留出空间。

### 4.4 hide：隐藏控件

```json
{
  "hide": [
    "@migrate",
    "@recover",
    "@toolbar .tools button[data-tool=\"4\"]"
  ]
}
```

hide 为选择器字符串数组，最多 300 项，默认空。支持与 styles 相同的组件别名、选择器列表和状态选择器。此例隐藏迁移、恢复备份和工具栏中的 Drag 按钮。隐藏只作用于当前皮肤，在切换或恢复默认时撤回；原先由应用隐藏的控件仍保持其应用状态，不会被强行显示。

匹配元素采用高优先级 `display:none`，不占布局空间、不参与鼠标命中或键盘焦点顺序。即使应用重新生成控件，或给控件设置普通内联 display，也继续按规则隐藏。设置和输入值、事件处理器、快捷键与功能本身保留；隐藏“保存”不等于禁用保存快捷键，隐藏勾选框也不等于取消勾选。用状态选择器可以有条件隐藏，用媒体规则中的 styles 可按窗口宽度隐藏。

需要隐藏一个带标签的输入时，应将标签或组合容器一起定位，例如 `.line-select-group`，仅隐藏 input 不会自动删除它旁边的标签。hide 不会自动删除空分组、补上替代入口或调整其他控件次序；这些通过 styles/organize 明确处理。独立的皮肤恢复控件与恢复快捷键保留。

原先就可以用 styles 的 `display:none` 或 `visibility:hidden` 改变可见性；后者仍保留占位，且普通声明可能受应用样式优先级影响。hide 提供专门的、不占位的隐藏规则，避免把“隐藏”和“销毁节点”混为一谈。不要用它隐藏整个工作台或画布后还假定该编辑视图可交互，控件是否仍有入口由皮肤作者负责设计。

## 5. styles：声明式 CSS

普通规则为 `{ "selector": "@header button", "set": { "border-radius": "8px" } }`。`set` 的属性名使用 CSS 的 kebab-case，可用标准 CSS 属性、浏览器支持的厂商前缀属性和 `--skin-*` 私有变量。每个 set 最多 100 个属性，属性值为非空字符串，最长 3000 字符。

支持选择器列表、子代/后代、属性、伪类、伪元素。别名可以组合，例如 `@save::before,@open::before`。别名中的 `@` 为协议保留语法，不应用于选择器字符串中的邮件地址。选择器最长 500 字符，必须能被当前浏览器解析；不存在的选择器暂时没有效果。

每个选择器分支都会加上 `:root[data-editor-skin="皮肤id"]` 作用域。以 `@root`、`:root` 或 html 开头的分支会与这个作用域根合并，可直接覆盖根变量；其他分支匹配其后代。以 `@app` 指定 body。即使使用逗号，各分支也分别保留皮肤作用域。

支持嵌套媒体规则：

```json
{
  "media": "(max-width: 700px)",
  "rules": [
    { "selector": "@workspace", "set": { "grid-template-columns": "minmax(0,1fr)", "grid-template-rows": "3fr 2fr" } },
    { "selector": "@file-actions", "set": { "overflow-x": "auto", "min-width": "0" } }
  ]
}
```

每个 rules 数组最多 1000 条，条件嵌套最多 4 层。media 支持逗号、斜杠、范围比较，如 `(width <= 700px), (aspect-ratio < 4/3)`。另外支持 `{ "container":"(width <= 360px)", "rules":[...] }`、`{ "supports":"(display: grid)", "rules":[...] }`、`{ "startingStyle":true, "rules":[...] }`，分别生成 @container、@supports、@starting-style。一个条件对象只有一种条件，用 rules 嵌套组合。编辑区域和右侧面板已经是 inline-size 容器；具名容器可在 styles 中通过 container-name 定义。条件仍禁止花括号、分号、注释、资源 URL 和转义；浏览器不支持的条件不会生效，应保留普通规则作为回退。

需要覆盖内联外观或复选框等旧有尺寸限制时，在规则旁声明 `"important":["width","height","color"]`。仅允许该规则 set 中的外观、文字、尺寸、间距、flex/grid、order、阴影和滤镜属性；不能给 display、visibility、pointer-events、position 等申请 important。应用的 `[hidden]` 与模式隐藏逻辑保留，装饰的 pointer-events:none 也是交互边界。普通 CSS 值里仍不能直接写 !important。

`properties` 可登记最多 40 个 `--skin-*` 自定义属性。例如 `"properties":{"--skin-example-progress":{"syntax":"<number>","inherits":false,"initialValue":"0"}}` 会生成 @property，syntax 支持 `*`、`<number>`、`<length>`、`<angle>`、`<color>`、`<percentage>`、`<time>`。initialValue 仍经过安全值校验，是否符合 syntax 及是否计算独立由浏览器决定。注册生效于当前样式表，名称请含皮肤 id 以避免冲突；切换后删除样式表，不调用永久的 CSS.registerProperty。

样式优先级依次由应用原有 CSS、皮肤基础层、皮肤图标规则、皮肤 styles 参与正常 CSS 级联；每条皮肤规则带有作用域的 specificity，同级时后写覆盖前写。应用的内联布局值和必需的 `[hidden]` 规则可能优先。不要假设 styles 总能覆盖所有内联几何；需要时修改其容器布局。

普通 CSS 声明值中禁止：raw CSS 文件、`@import`、`url(...)`、远程/数据/文件 URL、CSS 转义、注释、花括号/分号/尖括号、直接写 `!important`、`expression()`、`attr()`、`env()`、`image-set()`、`paint()`、`src()`、`behavior`、`-moz-binding`、`all`。条件表达式和 properties.syntax 采用上文单独规则，例如条件中的范围比较符和注册语法中的尖括号合法。资源必须通过下一节的宏引用；高 DPI image-set 由已声明 sources 生成。`:visited`、`:host`、`::slotted`、iframe 与皮肤恢复控件选择器也不可用。浏览器不支持的 CSS 属性或值可能被忽略，因此作者应在目标网页端与桌面端检验，不能仅依靠 JSON 结构校验。

## 6. 图片、字体、图标与装饰

```json
{
  "assets": {
    "save-blue": { "type": "image", "path": "images/save.svg" },
    "paper": { "type": "image", "path": "images/paper.webp" },
    "ui": { "type": "font", "path": "fonts/ui.woff2" }
  },
  "tokens": { "font-family": "font(ui), sans-serif" },
  "icons": { "save": "save-blue" },
  "styles": [
    { "selector": "@inspector", "set": { "background-image": "asset(paper)", "background-size": "cover" } },
    { "selector": "@save::before", "set": { "filter": "none", "width": "20px", "height": "20px" } }
  ]
}
```

`assets` 最多 256 项。图片支持 PNG/JPG/JPEG/WebP/GIF/AVIF/APNG/SVG，字体支持 TTF/OTF/WOFF/WOFF2，须以实际浏览器解码能力为准。GIF、动态 WebP、APNG 可直接作为动画图片；v1 不支持音频、视频、Lottie、可执行 SVG 动画和第三方运行库。

宏 `asset(id)` 仅引用 image，编译为本次载入的本地 blob URL 或高 DPI image-set；`font(id)` 仅引用 font，编译为皮肤命名空间内的字体名。可以在 background、content、border-image 等接受图像的 CSS 属性中使用 asset。字体加载完毕再应用皮肤，切换时释放。静态 SVG 可以使用基本几何、渐变、滤镜和本文件内 `<use href="#id">`；不能含 script、foreignObject、style、image、iframe、链接、animate/set 等活动元素、事件属性、外部 href、外部 URL、实体或 DOCTYPE。SVG 的 style 元素暂不开放，内嵌 CSS 需要另一套资源与选择器检查；用 presentation 属性和编辑器 motions 替代。

`icons` 可以继续使用“组件别名 → image id”对象，也可以使用数组，如 `[{"selector":"@play[data-playing=true]","asset":"pause-icon"},{"selector":".my-button:not(:disabled)","asset":"icon"}]`。数组支持任意合法选择器和状态；按声明次序级联。实现通过 `::before` 绘制 18×18 图标并保留文字、快捷键子节点与原功能。建议只用于按钮，不要给画布、input 等不能可靠显示伪元素的组件指定 icons。styles 可继续调整图标尺寸、margin、滤镜。

`decorations` 为 `{ "id":"sun", "target":"header", "asset":"sun-image" }` 数组，最多 24 项，id 唯一。也可用 selector 代替 target 以定位其他元素。placement 可为 prepend（默认）、append、before、after。每项针对第一个匹配目标，具有 `[data-skin-decoration=sun]`，为空 alt、aria-hidden、无指针事件，不会触发应用功能。max-width、尺寸和位置可通过样式覆盖；不允许恢复它的指针事件。无目标时等待目标创建；input、img、canvas、textarea、select 不接受内部插入装饰，可改为 before/after。

## 7. 动画 motions

```json
{
  "motions": {
    "panel-enter": {
      "from": { "opacity": "0.3", "transform": "translateY(3px)" },
      "to": { "opacity": "1", "transform": "translateY(0)" }
    }
  },
  "styles": [
    {
      "selector": "[data-panel]:not([hidden])",
      "set": { "animation": "motion(panel-enter) 160ms ease-out both" }
    },
    { "selector": "button:hover:not(:disabled)", "set": { "transform": "translateY(-1px)", "transition": "transform 100ms ease" } }
  ]
}
```

`motions` 最多 64 个动画，每个最多 40 个位置，位置为 `from`、`to` 或百分比字符串，如 `50%`、`12.5%`，声明规则与 styles.set 相同。`motion(id)` 编译为 `rpen-皮肤id-动画id`。CSS 的 duration、delay、iteration-count、direction、fill-mode、timing-function 等都可指定，也可只使用 transition。动画由 CSS 状态变化或元素进入 DOM 触发，也可使用第 13 节的只读状态与瞬时信号；不执行皮肤脚本。

启用系统“减少动态效果”时，编辑器强制将 CSS 动画和过渡缩短为近乎立即，并限制动画迭代。动画图片仍由浏览器播放，不能依赖这一机制停下，请另用 `prefers-reduced-motion: reduce` 媒体规则隐藏或替换它们。不要对大型可滚动列表的每个条目持续施加 blur/filter、阴影动画或无限动画。建议以 transform/opacity 为主，过渡约 100–200ms，避免影响画布性能。

## 8. texts：文字与无障碍

```json
{
  "texts": [
    { "selector": "@save", "text": "保存谱面 ", "title": "保存到本机", "ariaLabel": "保存当前谱面" },
    { "selector": "#project-search", "placeholder": "查找谱面" }
  ]
}
```

最多 300 项。每项需要 selector，其他字段可选，内容为最多 1000 字符的纯文本，允许空字符串。每个字段也可写成语言映射（`{ "zh-CN": "…", "en-US": "…" }`），匹配顺序为完整语言标签、同语种、`zh-CN`、映射首项。text 优先替换第一个非空的**直接文本节点**；控件标签被界面翻译包装进 `[data-i18n]` 元素时，兼容替换该标签的文字，仍保留包装、img、kbd、input 等子节点，不进入内嵌按钮或表单控件查找。皮肤提供的文案优先于应用默认翻译，中英文各自采用皮肤对应的名称，不用默认皮肤的称呼替换。不会用 innerHTML，不解释标签。没有可替换的标签时不制造整段内容，可改为针对内部 span 的选择器。input、textarea、select、canvas 及皮肤管理内的 text 不被替换，避免改变输入值或破坏恢复入口。

设置中的语言分类以“界面语言 / Language”显示，语言选择会持久保存并重新加载界面；有未保存谱面时先提示保存。`@language-settings`、`@language-select` 是 API 3 的兼容扩展，按这些入口定位，不依赖中文或英文标签内容。新用户默认音符资源包为内置 `builtin-sea-of-dreams`（Sea of Dreams - Neo），用户保存的音符皮肤选择优先；它独立于编辑器皮肤，不改变编辑器皮肤包的格式和词条。

title、ariaLabel、placeholder 分别修改同名 HTML 提示、aria-label、占位属性，不修改表单值。页面动态生成和状态改变后会重新匹配；同一元素同一字段的后续匹配项覆盖前项。状态不再匹配或卸载皮肤时复原应用原来的内容。应用主动更新的状态文字仍作为复原来源，不永久回写。

不要给播放/暂停按钮始终写同一个静态动作名；可使用 `@play[data-playing=true]` 与 `@play:not([data-playing=true])` 分开设置。不要覆盖用户输入、音符属性值、谱名或联机聊天为装饰文案。图标按钮必须有 title 或 aria-label，并保留键盘焦点提示。

## 9. canvas：编辑器画布

```json
{
  "canvas": {
    "fontScale": 1,
    "palette": {
      "#303030": "#f5f8fd",
      "#555555": "#bac8da",
      "#ffffff": "#345c8f",
      "#f6e5ce": "#705b40"
    }
  }
}
```

palette 的键必须为 `#rrggbb`；值为 `#rrggbb`，或以 `parameter(id)` 引用一个 type 为 color 的参数（API 3），例如 `"#e58d24": "parameter(event-fill)"`。引用在应用皮肤时解析为参数当前值，用户在设置中调整后画布随之重绘；引用不存在或非颜色参数会在导入时被拒绝。全局 palette、targets 和变体中的 palette 都可以引用。源色按绘制时的 RGB 匹配，支持原调用中的 #RGB、#RGBA、#RRGGBB、#RRGGBBAA、rgb()/rgba() 逗号写法，替换时保留原透明度。键推荐小写。经适配器创建的渐变，其 addColorStop 颜色同样映射；未匹配颜色、已经存在的外部渐变对象和图像像素保持原状；不存在自动反色或调换游戏素材的机制。

当前接入时间轴音符/事件/噪域、密度条与历史条（包括其离屏缓存）、音频分析、框选层、批量编辑虚线预览、事件缓动与 Bezier 编辑、曲线音符对话框、文字拼合结果、轨迹/噪域图案小预览、切线/剪贴板缩略图。接入依靠绘制入口显式包装上下文，不会自动拦截浏览器所有 canvas；新增绘制功能必须登记角色并接入。字体测量、文字/图片二值化等算法用画布不接入，避免改变生成结果。编辑器后面的 `#realtime-preview` 和播放 `#preview` 完全排除，取样实际渲染和 shader 输出不做色板改写。

编辑区域底部的横向判定线在网格之上单独绘制，颜色以用户设置为准，不受画布色板、透明度、线宽缩放或虚线配置覆盖；多线与全局事件的栏间空隙仍不绘制该线。

可参考的常用源色：

| 源色 | 常见用途（多个组件可能共用） |
| --- | --- |
| `#303030`, `#202020`, `#20252d`, `#292929` | 编辑底色、缩略图底色 |
| `#555555`, `#414956`, `#334154` | 网格或分隔 |
| `#4e545b`, `#71767c`, `#7f8387`, `#8f9095`, `#75777c` | 辅助刻度和横线 |
| `#ffffff`, `#dddddd`, `#d0d0d4`, `#f5f5f5`, `#d3d3d3`, `#cccccc` | 文本、轮廓、时间提示 |
| `#f6e5ce`, `#ffe0a3`, `#fff4c2` | 事件数值或强调文字 |
| `#80ffa0`, `#ffe080`, `#efe5ff`, `#a0ffdb` | 不同类别的事件数值 |
| `#00ffff`, `#ffff00`, `#80ffff`, `#81bfff`, `#ffdd77` | 选框、辅助线等强调 |

这是一种**绘制色板映射**，并非每一个图形都有独立语义 token；不要假设一个源色只属于一种对象。对不希望改变的语义色不作映射即可。编辑区底部判定线使用用户设置的颜色、宽度与不透明度，绕过皮肤画布映射，并绘制在横竖网格之上；预览缩放大于1时的默认视野白框同样属于编辑辅助，不受场景shader改变。

fontScale 为 0.7–1.8，默认 1，仅缩放画布文本的 px 字号，不改变音符几何、坐标、拍数与命中范围。canvas.font 可引用一个 font 素材，替换被接入的画布中 RPE/RPEGame 字族；不强制覆盖工具绘图有意选择的其他字体。DOM 字体使用 tokens.font-family 单独指定。

`canvas.targets` 允许针对角色覆盖同一套配置，角色表见机器目录 canvases：`notes`、`events`、`noise`、`density`、`history`、`audio`、`selection`、`batch-preview`、`easing`、`bezier`、`curve`、`text-lines`、`trajectory`、`noise-fit`、`line-thumbnail`、`clipboard-thumbnail`。例如 `"targets":{"events":{"palette":{"#ffffff":"#102030"}},"batch-preview":{"lineDash":[3,2],"lineWidthScale":1.5,"opacity":0.8}}`。全局 palette 与角色 palette 合并，角色同键优先；其他已指定参数覆盖全局。

opacity 范围 0–1，在绘制时乘以原 globalAlpha；lineWidthScale 范围 0.25–4，在描边时乘原线宽；lineDash 最多 16 个 0–100 数值，替换原代码设置的非空虚线，原有实线仍为实线。绘制完成后还原上下文数值，不改变命中几何。密度/历史缓存完成绘制后直接合成，避免透明度重复相乘。图片像素仍不可换色，音符仍使用已有资源包贴图。

## 10. 导入、持久化、切换与恢复

1. 设置中导入 `.rpenskin`/`.zip` 或文件夹。完整解析和素材解码成功后存入本机皮肤库，导入本身不会切换外观。
2. 选择皮肤，点击“预览 15 秒”。倒计时结束会回到预览前已保存的皮肤；可点浮动条“保留”或设置里的“应用”确认。
3. “应用”保存当前选择，重新打开编辑器仍使用它。网页端皮肤包存入单独的 IndexedDB，当前 id 与个人参数存入 localStorage；桌面端通过统一存储接口分别保存到谱面库的 `editor-skins` 与 `preferences`，沿用原生安全写入与更新继承规则。
4. “恢复默认皮肤”不删除已导入的包，也不清除其他皮肤已保存的参数。删除皮肤会同时移除包、该 id 的本机参数/变体偏好和未确认草稿；再次导入时使用包内默认值。删除已应用的导入皮肤会恢复默认；内置皮肤不能删除。

Ctrl+Alt+Shift+F12 是独立捕获的恢复快捷键，也可在设置中恢复默认。右下浮动确认条仅在限时预览期间显示，正式应用或保留皮肤后消失，不常驻恢复按钮；布局写坏时仍可使用快捷键。也可以在应用 URL 查询参数加入 `skin=default` 临时跳过自定义皮肤，例如 `?skin=default`。该参数不会删除皮肤包，也不会自行清掉保存的选择。

切换时恢复原控件顺序、文字和样式，释放旧字体和 blob URL，再应用新皮肤。启动时找不到皮肤或读取失败则使用默认并报告原因。解析/解码失败不会应用半套皮肤。导入同 id 的包前会询问替换，导入不能覆盖内置 id。

设置中显示 preview 图片、skinVersion 与 license，并按 parameters 自动生成可调控件。调整已应用皮肤的参数或变体会进入 15 秒预览，点击应用/保留后持久化，超时恢复已保存参数。若皮肤配置了 systemVariants，可选择跟随系统明暗。

“恢复此皮肤原始参数”恢复设置中所选皮肤的所有 parameters.default，保留其当前变体；若正在使用这套皮肤则立即应用并保存，无需再次确认，否则只清除该皮肤的自定义参数，不切换当前皮肤。Ctrl+Alt+Shift+Backspace 对正在使用的皮肤执行相同操作，与 Ctrl+Alt+Shift+F12 切换到编辑器默认皮肤不同。恢复后不会被此前的预览倒计时覆盖；其他皮肤的参数保持原状。覆盖安装同 id 的已安装皮肤仍保留个人参数；删除后重装则重新开始。启动时会清理已不存在皮肤留下的参数，修正早期版本遗漏清理的情况。

开发时，如果浏览器支持目录句柄，点击“导入文件夹”只读选择一次目录，此后“重读开发目录”会重新读取、校验并更新同 id 的包，当前正在使用它时自动进入预览。不重复弹出同包替换确认。目录授权仅在本次运行保留，不后台扫描或持续监听；不支持该 API 的环境继续使用普通文件夹导入。默认包的导入、重读和导出不包含个人参数，它们单独保存在本机；替换包的动作本身不由预览超时回滚。

皮肤是个人编辑器偏好，不进入谱面 JSON/PEZ，不发送给联机成员，不修改谱面未保存标记。网页端、桌面端、不同同源地址的存储独立。网页端清理网站数据也会清理导入的皮肤；桌面端更新或移动程序仍沿用原谱面库中的包、选择和参数，切换谱面库时使用目标库的个人设置。

应用维护者若要增加内置皮肤，将同样结构的目录放入 `assets/editor-skins/paper-example/`，再在 `assets/editor-skins/index.json` 中登记 `{ "directory":"paper-example", "files":["skin.json","images/icon.svg"] }`。目录名使用小写英文字母、数字或连字符，files 列出所有包内文件。内置与导入皮肤共用同一解析器和呈现协议，以平级列表显示名称与作者；内置包不接受同 id 的导入覆盖。

## 11. 资源限制与安全边界

| 项目 | v1 上限 |
| --- | --- |
| 包中文件数（含 skin.json） | 512 |
| 解压后总大小 | 32 MiB |
| 单文件大小 | 12 MiB |
| 输入 ZIP 本身 | 33 MiB |
| 单图片解码宽×高 | 1600 万像素 |
| assets / motions / decorations | 256 / 64 / 24 |
| hide 选择器 | 300 |
| styles 每层 / 嵌套 | 1000 条 / 4 层 |
| 单规则属性 / 动画关键帧 | 100 / 40 |
| parameters / variants / properties | 40 / 12 / 40 |
| 每个图片的额外高 DPI 来源 | 4，倍率大于 1 且不超过 4，不重复 |

ZIP 在解压前检查目录声明大小，在读取解压流时检查实际长度，并验证 CRC。SVG 会解析并检查活动内容，字体和图片须实际解码。浏览器 CSP 不因皮肤开放远程资源来源；字体仅补充允许本地 blob。没有文件系统、网络、剪贴板、聊天或命令执行 API。

CSS 仍有很大的布局自由，错误主题可能遮挡按钮、制造低对比或过量动画。导入校验不是视觉可用性认证，也不保证任意压缩图片/字体解码的内存成本固定。分发前必须做以下验收；保留恢复机制，并避免导入来源不明的巨大媒体。

## 12. 制作、打包和验收

可参考内置皮肤 `assets/editor-skins/inkline/` 的清单、素材引用、命令分组与响应式规则。制作新皮肤时应使用自己的 id，不要覆盖内置标识。

在仓库目录运行：

```sh
node tools/pack-editor-skin.mjs path/to/my-skin release/editor-skins/my-skin.rpenskin
# 省略输出文件时，生成 release/editor-skins/<皮肤id>.rpenskin
```

打包器进行与导入器相同的纯数据校验；浏览器导入继续验证 CSS 选择器和媒体解码。`node tools/editor-skin-spec.mjs` 从运行时组件/变量定义重新生成 schema 与目录。`npm test` 包含协议解析、安全、打包导入和画布隔离测试。

程序化界面回归可先设置环境变量 `RPE_PORT=4187` 并运行 `node tools/serve.mjs`，再用 `electron tools/test-editor-skin-electron.cjs`。测试使用最小合成测试数据和独立本机数据目录，不依赖额外主题包，输出截图到忽略提交的 `.local-tools/`。服务地址可用 `RPE_SKIN_TEST_URL` 指定。

建议人类或 AI agent 按以下顺序制作：

1. 阅读本文、Schema 和组件目录，复制最小清单，先决定色系、字体、信息密度与右侧面板宽度。
2. 先完成 tokens 与画布底色/文字色板，检查普通/选中/禁用/悬停/键盘焦点的对比。
3. 逐个处理顶栏、播放栏、工具栏、编辑头栏、右侧页面、主界面、列表、弹窗、通知和右键菜单。所有功能都应可发现。
4. 有必要时使用 organize 重组命令；不要克隆有 id 的按钮、用文字模拟按钮或改变表单值。
5. 注册原创或获准分发的素材，使用 asset/font/motion 宏；为图标保留文字或无障碍名称。静态 SVG 与动画素材分开考虑。
6. 在编辑、播放预览、单线/多线、噪域、取样、批量编辑、素材库、设置、主界面及弹窗中检查效果。后四类动态页面也必须可读。
7. 至少检查约 1440×900、1000×680、600×800 的窗口，以及系统字体缩放、高 DPI、减少动态效果；窄窗口使用滚动而非裁掉主要操作。
8. 验证导入不直接应用、预览超时恢复、重启恢复、自定义皮肤间切换、恢复默认、删除皮肤、错误包拒绝，确认原有保存、选择、撤销功能仍能工作。

协议后续可增加组件别名、语义画布颜色等入口；v1 作者应优先使用本文明确的稳定入口，对源码特定 class/id 的高级定制保留回退。需要执行脚本、自定义编辑逻辑或新型控件的功能应作为应用功能开发，不能通过皮肤绕过。

## 13. API 2 作者指南与完整扩展示例

### 13.1 响应式变量、局部配色、系统明暗

```json
{
  "compatibility": { "minApi": 2 },
  "styles": [
    {
      "media": "(width <= 900px), (aspect-ratio < 4/3)",
      "rules": [{ "selector": "@root", "set": { "--rpen-inspector-width": "280px", "--rpen-font-size": "12px" } }]
    },
    {
      "selector": "@inspector",
      "set": { "--rpen-surface": "#f4f8ff", "--rpen-text": "#203040", "--rpen-input": "#ffffff" }
    },
    {
      "container": "(width <= 360px)",
      "rules": [{ "selector": "@panel-title", "set": { "padding": "8px 12px" } }]
    },
    {
      "media": "(prefers-color-scheme: dark)",
      "rules": [{ "selector": "@root", "set": { "--rpen-background": "#152030", "color-scheme": "dark" } }]
    }
  ]
}
```

样式的作用域优先级仍高于许多旧应用规则，协议不会自动猜测作者要保留哪些响应式样式。自己覆盖了 padding、字号等布局属性后，应补充相应容器规则；系统明暗可用此处的 media 规则，也可用下节的成对变体，但不要同时写互相冲突的两套配色。inspector-width 是工作台父容器使用的值，要在 @root 或 @workspace 上覆盖，在 @inspector 内定义不会反向影响父容器宽度。

### 13.2 可调参数与同包变体

```json
{
  "skinVersion": "1.2.0",
  "compatibility": { "minApi": 2 },
  "license": "填写此皮肤实际采用的许可与必要声明",
  "parameters": {
    "panel-width": { "type": "number", "label": "侧栏宽度", "min": 260, "max": 520, "step": 10, "unit": "px", "default": 350 },
    "accent": { "type": "color", "label": "强调色", "default": "#2469d9" },
    "dense": { "type": "boolean", "label": "紧凑倾向", "default": false },
    "corners": { "type": "select", "label": "圆角", "options": { "2px": "轻微", "8px": "圆润" }, "default": "8px" }
  },
  "tokens": { "inspector-width": "parameter(panel-width)", "accent": "parameter(accent)", "radius": "parameter(corners)" },
  "variants": {
    "day": { "name": "日间", "colorScheme": "light", "tokens": { "surface": "#ffffff", "text": "#203040" } },
    "night": { "name": "夜间", "colorScheme": "dark", "tokens": { "surface": "#172330", "text": "#eaf1fa" } }
  },
  "systemVariants": { "light": "day", "dark": "night" }
}
```

参数 type 为 number/color/boolean/select，需要 label 和 default；label 与 select 的选项文本同样可以写成语言映射。数值必须提供有限的 min/max/default，可提供正 step（默认 1）和 unit：空、px、em、rem、%、ms、s、deg。应用时钳制范围；颜色为 #rrggbb，开关编译为 0/1，选择参数的键是安全 CSS 值、值为界面标签，default 必须是已有键。`parameter(id)` 编译为 `var(--rpen-param-id)`；可在 calc 等表达式中使用，定义参数本身不会自动引入编辑器行为。颜色参数还可以直接作为 canvas palette 的值（API 3，见第 9 节），让时间轴等画布与界面配色一起调整；画布值只接受完整的 `parameter(id)`，不支持 color-mix 等表达式，需要派生色时请另设参数。

variants 的每个条目需要 name，可覆盖 colorScheme、tokens、styles、canvas。基础规则与变体规则依次叠加，变量按键覆盖，画布全局 palette 按键合并，targets 按角色替换后由绘制器与全局配置合并；不会重建另一套功能结构。最多 12 个变体，id 不可为 base/auto；base 为基础外观，auto 为跟随系统。systemVariants 必须指向已有的 light/dark 两个变体，可指向同一变体。

本轮不实现跨包继承、任意多个皮肤同时叠加。这样导入包不依赖本机是否安装某个父皮肤，切换和导出结果可重现。共享外观可放同一包的基础字段，差异放 variants；需要分发两个包时由作者工具在打包前展开共享定义。

### 13.3 只读界面状态与瞬时信号

文档根始终提供下列稳定属性，皮肤不需从按钮文字反推：

| 根属性 | 值 |
| --- | --- |
| data-rpen-playing | true / false |
| data-rpen-dirty | true / false，包含素材未保存状态 |
| data-rpen-pane | 当前右侧页面名 |
| data-rpen-mode | notes、notes-events、multi-notes、multi-events、noise、global-events |
| data-rpen-location | home、editor、preview |
| data-rpen-collaboration | offline、connecting、ready |
| data-rpen-beat | 当前拍数向下取整的整数 |

例如 `@root[data-rpen-dirty=true] @save` 高亮未保存按钮，`@root[data-rpen-pane=assets] @inspector` 改变素材页面配色。状态用于样式，不赋予修改状态的能力，也不暴露消息文本、成员昵称、文件路径等隐私。

信号以约 180ms 的根属性脉冲呈现，属性名为 `data-rpen-event-信号名=true`。登记信号：beat（播放跨越整数拍）、save-started、save-succeeded、save-failed、error、warning、collaboration-changed。信号再次触发会先清除再在下一帧置为 true，可用属性选择器重新启动 motion。它们用于装饰和反馈，不是完整事件总线；快进跨多拍只发当前跨越信号，不回放中途每拍，减少动态效果偏好仍生效。不要依赖信号执行谱面操作。需要完整的逐拍动画可依据 beat 状态设计，但协议不提供任意 JS 回调。

### 13.4 内置图标、高 DPI 与素材复用

全局事件新增稳定别名 `global-events-tool`、`close-global-events`、`global-events-panel`、`global-event-types`、`global-event-density`、`global-event-inspector`、`global-event-properties`；页面名为 `global-events`（总览）和 `global-event-properties`（独立属性），没有常驻标签。画布角色 `global-events` 和 `global-density` 分别控制事件时间轴和横向密度条，沿用全局色板并可在 canvas.targets 单独覆盖。全局事件列宽由普通事件基准或提供方注册项决定，总览不提供调宽控件。

```json
{
  "assets": {
    "native-save": { "type": "image", "builtin": "save" },
    "picture": { "type": "image", "path": "images/picture.png", "sources": [{ "path": "images/picture@2x.png", "scale": 2 }] }
  },
  "icons": [{ "selector": "@save", "asset": "native-save" }],
  "preview": "picture"
}
```

builtin 必须使用组件目录 builtinAssets 表中登记的有限名称，不能输入任意应用文件路径。当前包含 folder、save、setting、help、play、replay、showback、jump、copy、shear、paste、delete0、switch、layout、return、info、waves、bezier、addline、mute；复用时无需把这些图片拷贝进包，应用升级由目录保持引用映射。未列出的音符/打击素材不作通用资源接口。

普通 image 的 path 为 1x 来源，sources 提供最多 4 个额外倍率，倍率须大于 1、不超过 4 且互不重复。每张来源都计入文件与大小上限并解码校验。asset()/icons 的背景生成 image-set，装饰使用 srcset，浏览器按显示密度选择；显式预览图使用 path 的基础来源。字体与 builtin 不接受 sources。为了避免接入任意资源字符串，直接在 CSS 中手写 image-set/url 仍禁止。

动画曲线是编辑器内的大浮窗，直接继承当前皮肤；不创建系统子窗口。组件别名 animation-curve 指向 #animation-curve-editor，custom-easing-templates 指向 .custom-easing-group。布局保留可拖动标题栏、画布、长纵向滑条、侧栏、帮助与右下角缩放柄。帮助图示使用当前颜色令牌；无额外的模组运行环境。

视频渲染：render-video 指向顶部唯一入口 #render-video（首页禁用），render-studio 指向按需创建的 #rpen-render-studio。不得在皮肤中复制渲染入口。面板继承皮肤颜色；详见 VIDEO-RENDER.zh-CN.md。

整窗录制渲染使用快捷键；`@editor-recording-status` 为录制期间才创建的左下角状态／停止按钮，`@editor-render-fps` 为设置中的目标帧率。均继承普通控件外观，无须皮肤添加新入口。

`@editor-render-settings` 为统一默认折叠的播放渲染设置面板，`@editor-render-auto-play` 为开始时自动播放。`@key-display` 是独立的按键显示开关；`@key-display-overlay` 为启用时才创建的右下角顶层键帽容器，pointer-events 为 none，不影响布局、焦点和鼠标操作。
# RPEN 全局事件协议 v1

全局事件不属于判定线，不受当前线、事件层、判定线 BPM 倍率或多线模式影响。时间使用谱面 BPM 表和 `[整数, 分子, 正分母]` 拍数，谱面延迟沿用正常播放规则。宿主提供注册、时间轴、密度总览、属性编辑、事务和存储，各事件的实际播放语义由提供方定义。

## 1. 页面和交互

“谱面工具 → 全局事件”打开非常驻总览页，左侧进入全局事件模式，没有新增常驻标签。总览逐类显示名称、来源、事件数、列数和横向全曲密度条。密度按事件覆盖时间统计，同类型多列合并，可点击定位。

只选中一个事件时打开独立属性页，属性页不包含种类列表和密度条，可返回总览。选中多个事件时显示总览，暂不提供右侧批量属性编辑。总览和属性页分开实现。切换其他右侧页面可保留左侧工作区；总览、属性页中的“关闭全局事件编辑”或工具栏“× 全局事件”均可退出编辑模式。

一类事件可以有多列。同类连续排列，不同类间隔 18 CSS 像素。默认列宽等于普通“音符＋事件”视图的一列事件，不随全局列数拉伸；窗口尺寸变化时跟随普通编辑区基准。页面不提供调宽控件；注册项的 `column.width` 优先于 `type.width`，可指定 24–2048 CSS 像素。横线、竖线和底部判定线仅绘制在事件栏范围，每栏左右有细边界，间隔及末列以外保持空白。列多时可拖动空白处横向浏览或使用横向滚动条。

支持 Q/R 两次放置、Q 钩定、拖动事件平移和首尾缩放、Ctrl 多选、Shift/中键框选、复制/剪切/粘贴、删除、撤销/重做、滚轮调时间。空白拖动用于横向浏览，不进行划线多选。多选仍可进行时间轴拖拽、删除等操作。文本框保留原生快捷键；有效数值、拍数和文字输入时即应用，保留当前输入字符串和光标，不要求按回车，暂未完整输入的内容不会写入。默认数值列 A 取反首尾，S 把尾值设为首值，列可自行改写。音符工具、多线切换等没有全局事件含义的操作不执行。

内置 `rpen/placeholder` 只测试编辑，不产生效果。其数据仅存当前会话，可撤销重做，不影响谱面或未保存状态，不写入导出文件；重新打开谱面清空。

## 2. 注册、来源和命名

Mod API 1 新增 `api.globalEvents`。注册自动归属当前模组，返回注销函数，停用也会自动注销实现。

```js
export function activate(api) {
  api.globalEvents.register({
    id: 'wind',
    name: `${api.manifest.name} · ${api.manifest.author}`,
    description: '由模组解释的二维风场',
    columns: [
      { id: 'x', name: 'X', valueType: 'number', defaultValue: 0 },
      { id: 'y', name: 'Y', valueType: 'number', defaultValue: 0, width: 120 },
      { id: 'mode', name: '模式', valueType: 'text', defaultValue: 'calm' }
    ]
  });
}
```

宿主构成 `<模组 id>/<类型本地 id>`；内置使用 `rpen/<类型本地 id>`。类型本地 ID 和列 ID 以小写字母开头，随后允许小写字母、数字、点、下划线、连字符，最长 96 字符。显示名可以改，稳定 ID 变更须由提供方迁移数据。禁止重复注册。

**模组新增的持久化全局事件必须在谱面中标识来源模组 id、name、author、version；推荐用“模组名 + 作者名”命名类型。** 托管接口从清单自动写入来源，模组不得伪造来源；直接修改原始谱面或替换导出机制时也必须遵守这一要求。

## 3. 定义接口

类型必需 `id`、`name`、非空 `columns`。可选 `description`、`width`、`persistent`（默认 true）、`validate(event,column)`、`inspector(context)`。

每列必需 `id`、`name`，可选项如下。

| 字段 | 含义 |
|---|---|
| valueType | number（默认）、text、boolean、color、json |
| defaultValue | 默认依次为 0、空字符串、false、[255,255,255]、null |
| min/max/step | 数值约束及步长，step 大于 0 |
| width | 固定 CSS 像素列宽，覆盖类型 width |
| timelineLabel | 可选时间轴短标题，避免完整类型名在窄列中被压缩；总览及属性页仍显示完整名称 |
| overlap | 默认 false，新建放置是否允许区间重叠 |
| create(context) | 最终放置时补充事件数据，返回事件或 null 取消；虚影每帧绘制不执行 |
| validate(event) | 同步校验，返回 false、错误文字或抛错拒绝提交 |
| formatValue(value) | 时间轴首尾值的文字 |
| draw(context) | 在事件条上附加绘制，已裁剪并 save/restore 画布状态 |
| inspector(context) | 添加专属属性控件，可返回清理函数；覆盖类型 inspector |
| shortcut({action,event}) | NumberMirror/NumberFill 操作，返回新事件或 null 保持不变 |

数值必须有限；颜色为三个 0–255 数的 RGB 数组；json 和额外字段可为任意可保存的 JSON 数据，不能包含函数、DOM、循环引用、NaN、Infinity 等。`overlap` 负责新建检查，拖拽及属性编辑与普通事件一致；需要更严格约束的提供方可在事务提交前检查整列。

```js
// create(context)
{ event, previous, type, column }
// draw(context)：rectangle 为 CSS 像素，context 已处理设备像素比
{ context, rectangle, event, selected, tempo, seconds, timeline, type, column }
// inspector(context)
{ container, event, entries, type, column, update, editor, document }
```

属性控件仅在单选时创建，调用 `update((event, entry) => nextEvent, label?)` 提交不可变事务，可撤销重做；`entry` 含 type、column、key、events，表示当前列。传入的 event/entries 是副本，entries 仅含一个选中事件；多选不创建属性控件，update 也不会执行右侧批量修改。返回的清理函数在属性页重建、退出或重置时执行。默认属性页提供首尾拍、值、钩定、缓动与图示、缓动范围、绑定组、Bezier 和完整 JSON 编辑。

这些接口没有把事件限定为数值缓动：可增加任意数据、专属控件和绘制。更深的界面、交互、求值和语义仍可组合通用 `api.patch`、`api.hook`、`api.onFrame`、`api.onPreview` 和 `api.editor`。注册、校验、绘制及属性回调是同步函数，校验不得修改原对象。

## 4. 读写和生命周期

```js
api.globalEvents.open();
const types = api.globalEvents.list();
const copied = api.globalEvents.read('wind', 'x');
api.globalEvents.replace('wind', 'x', [
  { startTime: [4,0,1], endTime: [8,0,1], start: 0, end: 12,
    easingType: 1, custom: { mode: 'gust' } }
], '修改全局风场');
```

list 返回类型、来源、持久化/只读状态和列摘要。read 返回深复制，支持本地或完整 ID，完整 ID 可读取其他提供方的列。replace 只修改本模组命名空间，自动标注来源，一次写入谱面历史并更新未保存状态；失败不部分提交。

停用模组只注销实现，**不删除事件数据**。总览和时间轴保留未加载类型，只读展示，保存时完整保留未知字段；重新启用后恢复编辑。提供方变更 schema 或减少列时必须自行迁移旧数据，重新注册不能抹掉未识别数据。

全局事件数据属于谱面，随谱面库保存、恢复副本和 Next JSON/PEZ 保留；模组包、是否启用及其个人设置是独立数据，不随谱面一起安装。网页端与桌面端共用这些业务规则，模组不应依赖 IndexedDB 名称或原生文件路径，参见[模组协议的存储约定](MOD-PROTOCOL.zh-CN.md#61-保存个人设置与平台存储)。

persistent:false 与占位一样仅存本次会话，不应承载需要保存的内容。联机中临时数据仅属本机；持久化数据走现有事务同步。目前全局数据以整个类型对象为冲突粒度，不提供逐事件协作锁，提供方需注明其联机策略。

大列的 read 深复制有成本，播放求值应缓存轨道，在谱面引用变化时重建；不要每帧 commit 谱面。内置后续类型可使用同一 registry/document 接口，无需接入判定线事件数组。

内置“三维摄像机”提供位置 X/Y/Z、偏航/俯仰/画面倾斜及视角七列，展示全局事件驱动的透视渲染、自定义属性控件、拖拽草稿和跨列原子生成。坐标、求值和文件约定见 [模组说明](../assets/mods/spatial-camera/README.zh-CN.md)。

## 5. 谱面结构和导出

仅实际写入持久化事件时新增 globalEvents，版本为 1；包含它的 Next 文件 META.RPEVersion 至少为 240，旧谱面不因此改变。可选 width 可写入类型或列元数据，供未加载类型展示。

```json
{
  "globalEvents": {
    "version": 1,
    "types": {
      "example/wind": {
        "name": "Wind · Writer",
        "source": { "kind": "mod", "id": "example", "name": "Wind", "author": "Writer", "version": "1.0.0" },
        "columns": {
          "x": {
            "name": "X", "valueType": "number",
            "events": [{ "startTime": [4,0,1], "endTime": [8,0,1], "start": 0, "end": 12, "easingType": 1 }]
          }
        }
      }
    }
  }
}
```

内置来源为 kind:builtin,id:rpen,name:RPE Next；模组来源必须完整并匹配命名空间。事件必需首尾拍数和 start/end，结束拍不早于开始拍。缓动沿用 1–29、easingLeft/easingRight/bezier/bezierPoints，其他字段由提供方约定。

Next JSON/PEZ 按每列开始拍稳定排序，保留全部属性。原 RPE 导出须明确勾选在副本中移除全局事件，不能无提示丢弃；原谱不变。占位不保存，所以不触发此提示。

谱面仅保存 JSON 和来源，不包含可执行模组代码；载入谱面不会因来源信息自动下载、导入或启用模组。完整类型声明见 schemas/mod-api-v1.d.ts。

全局事件的 customEasing 与普通、扩展、噪域共用自定义动画曲线 v1；持久化数据包含完整快照，格式版本至少 250，详见 ANIMATION-CURVES-PROTOCOL.zh-CN.md。未知提供方保持只读；RPE 仍需明确移除全局事件。
# 超大谱工程：查看、编辑与保存

桌面版导入窗口中的“超大谱 · 查看与编辑”提供独立入口，以原生桥接能力识别支持，不按操作系统或盘符限制。选择谱面包后可以播放查看，点击“进入编辑”使用普通音符和事件界面。完整谱面保存在磁盘数据库中，编辑器只加载当前时间窗口，不加入普通谱面库。网页版尚不提供此入口。

当前支持 ZIP／PEZ 中的一份 PEC 文本谱面，包括文件名为 `.json` 的 PEC。支持 BPM、判定线移动／旋转／透明度／流速，以及 Tap、Drag、Flick、Hold 和独立／行内的 `#`、`&` 参数。RPE JSON、ZIP64、自定义脚本与 shader 尚未接入。

可播放、暂停、拖动时间、变速和调整音量。音乐直接流式播放，不解码整首 PCM。普通编辑预览复用音符、判定线、游戏 UI 和分组打击特效；打击音效使用原有开关、音量、Tap/Drag/Flick 延迟与皮肤声音，按完整谱面查询短时间区间。重合音符以带数量的音频脉冲合成，不按声部上限丢弃，也不创建百万声部。独立查看窗口暂不绘制打击特效或播放打击音效，进入编辑后可使用。封面仅解码尺寸通过检查的 PNG／JPEG。

## 编辑与重合音符

普通放置、拖拽、属性修改、跨线移动、复制、剪切、粘贴、删除、曲线生成和事件修改均经普通编辑会话提交。音符使用稳定的数据库标识；提交只比较已加载的页面，未加载的音符不会因缺席而被删除。跨越窗口的 Hold 和移出窗口的选中音符会继续加载，多线模式按所选判定线读取。

工具栏中的“超大谱工程”图标打开紧凑选项面板，沿用界面与皮肤样式，不再显示额外的常驻说明栏。单选默认处理 **1** 个重合音符，可指定数量或处理整组；这项设置只影响单选。局部修改会拆出对应数量，其余音符保留。

多选按实际数量选择完整音符：框选查询全部指定区间，滚动前后的区间不因页面未加载而遗漏；Ctrl+A 选择目标判定线上的全部音符，Ctrl 加选/减选和跨线选择保留屏外项目。绘制继续使用有限代表音符，完整选择保存在 SQLite。批量移动、属性修改、复制、剪切、删除及撤销重做按完整逻辑选择分批处理，保持一次事务，不受绘制页 40000 分组上限限制。间隔选择会按设置的步长计算数量，不展开重合组。

复制值不携带原数据库标识，粘贴生成新组。可在传输预算内携带的剪贴板保存实际数量，可跨超大谱工程使用；超过预算的大选区保留在原工程的磁盘剪贴板中，仍能完整复制粘贴，不能在关闭原工程后把代表音符误当作完整剪贴板。普通谱面暂不接受多音符重合组，以免静默减少数量或突然展开海量对象。

BPM、线倍率、流速和判定线顺序变化时，后台分批重建完整索引；整条判定线复制和删除覆盖未加载音符。单次绘制页最多 40000 个不同音符组，预取边距超限时退回可见区间；密集区间自动提高纵向缩放以完整显示当前页面，达到缩放上限后仍超限则报告错误。逻辑选择和整次批量编辑通过磁盘集合分批执行，不按绘制数量截断。

## 保存、重开与恢复

本入口还可打开 `.rpenlarge` 工程。“保存”保存整个工程，“工程另存为”和本模式中的“导出”均另存完整工程，包含全部音符、事件、音乐、封面及持久化的撤销/重做记录；不会把当前页面当成普通 JSON/PEZ 导出。工程可保存在任意磁盘的缓存目录之外；保存时按目标卷检查临时数据库所需空间，并保留 1 GiB 余量。目标父目录会解析为实际路径，不能通过链接把工程放回待清理缓存内。

`.rpenlarge` 保存了已经完成的索引；直接重新打开它可跳过 ZIP/PEC 解压、逐行解析和首次索引。仍需复制工作数据库和准备少量媒体，但不会重新展开原谱文本。重新选择原 ZIP/PEZ 则仍是首次导入流程，不会自动把未保存的临时索引作为长期缓存。

每次修改在后台事务中提交，校验或预算失败时整次回滚。撤销/重做同步处理音符、事件、线号和选择状态，保存重开后仍可使用；界面每次只读取前后各 150 条历史标签，完整记录仍保存在数据库中。

保存先生成独立临时数据库，写入保存点、执行 SQLite 完整性检查并同步文件，最后替换目标文件。失败保留原工程和未保存状态，不提前把工作数据库标记为已保存。异常退出时保留未保存缓存，下次使用同一位置时可选择恢复，同时读取未合并的 SQLite WAL。明确放弃修改才删除对应缓存。

超大谱工程独立于普通恢复副本。版本控制、联机、AI、全谱检查及素材库编辑尚未接入完整磁盘文档，因此本模式暂时停用这些入口。

## 存储与资源边界

- 首次使用由用户选择可写且空间充足的普通目录，其下建立专用的 `RPEN-LargeChartPreview`；文件夹选择器从所选源文件附近开始，不固定盘符。缓存父目录和专用目录拒绝目录链接/重定向，内部路径按实际位置校验；既有 E 盘配置和未保存缓存仍按原格式读取与恢复。
- 不展开原始谱面文本。按压缩包范围流式解压、校验 CRC，逐行索引到临时 SQLite。
- 总缓存预算 1 GiB，其中数据库最多 768 MiB、音频和封面共 96 MiB，编辑事务日志计入预算；开始前检查至少 2 GiB 可用空间，处理中检测 1 GiB 的剩余空间余量。
- 后台线程旧生代上限 256 MiB，并检查 JS 堆和 ArrayBuffer 共 192 MiB 的预算。SQLite 页缓存 8 MiB，不使用磁盘临时文件及内存映射。
- 最多 256 条判定线、16384 行事件、256 个线号／音符流速组合。单次预取最多 40000 组不同音符，超限暂停并报告，不静默丢弃。
- 画布最多 1920×1080；GPU 贴图缓存最多 64 MiB。上述上限是各部分预算，并非整个 Electron 进程的内存上限。
- 取消或关闭已保存工程时停止后台线程，再清理专属缓存；未保存工程保留用于恢复。缓存目录名称保留为 `RPEN-LargeChartPreview`，兼容既有配置。
- 只清理带所有权标识的 UUID 工作目录，遇到未知文件或链接会保留并报告，不递归删除用户目录。

## 索引与绘制

相同线号、类型、时间、坐标、上下方向、虚假标记、速度及宽度的音符合并存储，保留数量和首次出现次序。计分及多押统计按实际数量累计；Hold 在结束时间计入完成数量。

只查询当前时间附近的音符，用区间索引覆盖流速反转、零速和跨越窗口的 Hold。跨进程传输采用固定字段的 Float64Array。密集区间自动缩短预取时间，保留当前可见音符及需要的特效回溯区间；若后台未及时返回，暂时等待数据并保留播放意图，最新有效的画面和音效数据就绪后自动继续。过期请求不清除续播意图，手动暂停、暂停式定位或退出会取消续播。真实可见数据仍超出预算时明确暂停并提示。

GPU 使用 `1 - (1 - alpha)^count` 累积相同贴图的透明度，不展开成百万次绘制。不同音符组交错时的覆盖次序、纹理边缘和重复 Hold 部件之间的混色可能与逐个绘制不同，尚不承诺所有皮肤逐像素一致。

## 验证入口

- `node --test test/large-chart-editing.test.mjs`：局部编辑、千万级重合组、剪贴板、时序、整线操作、回滚、保存重开与预览回溯。
- `node --test test/large-chart-playback.test.mjs`：缓冲后续播、手动暂停取消、带重数的打击音效和过期请求处理。
- `node --test test/large-chart-storage.test.mjs`：系统临时目录中的缓存、跨位置保存/重开、IPC 选择与保存、目录链接/越界及恢复路径。

视频渲染通过完整磁盘文档读取 window/hits，按 count 保留重合数量。soundNames 只返回有界去重音效名（最多512种），用于音频准备，不展开全谱；渲染检查 revision，数据改变时终止。接口与预算见 VIDEO-RENDER.zh-CN.md。
# RPEN 模组协议与开发指南 · API 1

AI命令扩展：`api.agent.register(definition)` 可将任意模组功能注册给内置Agent，`api.agent.list()` 查看工具结构，卸载自动注销；通用谱面工具也能读写模组字段。权限、只读prepare、变更计划、执行一致性和Provider扩展详见 [AI Agent协议](AI-AGENT-PROTOCOL.zh-CN.md)。此项为API1兼容扩展，不要求旧模组修改。

模型请求按需携带工具定义，新增模组命令可通过 `agent_tools` 发现，注册接口和完整 `api.agent.list()` 不变。`api.editor.agentWorkspaceId` 是当前谱面的稳定本地 AI 工作区标识；`await api.editor.agent.ready` 等待对话恢复，`await api.editor.agent.flush()` 等待本地记录落盘。可信扩展可使用 `api.editor.agent.workspace` 管理该工作区文件；桌面端限制在独立目录，不授予任意磁盘或终端访问。对话及原始请求属于用户本地数据，模组不应未经用户要求上传或读取无关内容。

本协议定义可执行的编辑器扩展。模组可以修改界面、交互、渲染、编辑语义、谱面数据、导入导出和存储流程，也可以实现独立工具或游戏。内置示例不构成能力白名单。编辑器皮肤和音符皮肤属于各自的数据协议；模组可以调用、扩展或替换它们的实现。

机器可读清单见 `schemas/mod-v1.schema.json`，接口声明见 `schemas/mod-api-v1.d.ts`。API 1 从当前开发版本提供。`api.version` 是模组宿主接口版本，`mod.json.version` 是模组自己的版本，与谱面的 `RPEVersion` 相互独立。

## 1. 权限与用户流程

右上角“模组”打开独立管理器，可查看包内源码、启停、配置快捷键与参数、恢复默认参数、导入、导出和删除。右下角显示实际已装载数量。首次使用没有自动启用的模组；用户启用过的模组会在下次启动时自动装载。删除外部模组会清除其参数和专属存储。内置模组可以禁用、配置及导出，但不能删除或被同 ID 外部包覆盖。

外部包在解析和语法检查后、保存和执行前必须经过风险说明与主动勾选确认。确认导入后仍处于禁用状态。替换已有包再次显示风险提示，并停用原版本。风险提示说明完整编辑器权限、未知影响、作者免责，以及可信来源、源码或 AI 检查和备份建议；检查并非安全保证。

**模组与编辑器在同一个 JavaScript 页面运行，没有模组权限沙箱。** 它可以访问页面 DOM、当前编辑器存储中的谱面与设置，执行网络请求，调用宿主公开对象、导入内部模块和改写原型。网页端访问限于同源存储；桌面端也可通过编辑器的存储接口读取、修改或删除所选原生谱面库中的数据。启用意味着信任其全部代码。管理器的包大小、路径和语法检查用于诊断和防止意外资源耗尽，不是恶意代码隔离。

网页仍受浏览器权限、同源策略、CORS、CSP 和文件选择授权约束。桌面版渲染进程没有 Node.js、任意磁盘读写或终端接口；模组不能借本协议突破这些边界。远程脚本可能被 CSP 拦截，依赖应打包进模组。网络请求也不因本协议获得额外跨域权限。模组不可假定 `eval`、`new Function`、Node.js `require` 或 npm 裸模块名能运行。

### 1.1. 在线市场与安装计划

内置“Nyamon 模组市场”由 NyamonZone 提供，使用 API 1 的普通模组能力，默认禁用。它增加目录、依赖安装、发布页和更新检查；[使用说明](../assets/mods/rpen-mod-market/README.zh-CN.md)记录网络范围、配置和恢复入口。市场服务协议由服务提供者维护，不属于宿主 API 1 的稳定方法契约。

在线下载与文件导入遵循相同的风险确认规则：依赖和替换包也须分别审阅并主动勾选；整个计划校验与审阅完成前不得写入或停用原有包。默认不执行下载代码；若提供安装后恢复启用，必须单独选择并说明会运行新版本及受影响的依赖者。内置 ID 和市场自身不可由在线包覆盖。

覆盖前应持久化旧包及参数备份，失败时按实际存储恢复，不能先删除旧包的最后一个副本。恢复未完成时保留备份、提供恢复及导出入口，并停止新安装；管理器不能把未恢复的旧版本显示为已经恢复。正常关闭窗口、切换服务及停用产生的 `AbortError` 应由模组处理为取消，其他异常继续遵循宿主错误规则。

浏览、反馈和更新检查应说明联系的服务及提交的数据。更新检查默认限于当前市场来源，其他包由用户手动选择，提交范围为模组 ID、版本和内容哈希。修改服务配置必须取消旧任务、关闭旧连接及清除会话，提示与实际接收地址一致。

## 2. 包结构与清单

导入 `.rpenmod` 或 `.zip`，两者均为 ZIP；也支持选择整个文件夹。根目录需有唯一 `mod.json`，允许 ZIP 最外面多一层目录。文件采用 UTF-8；路径用 `/`，区分大小写，不允许绝对路径、反斜杠、`..`、查询或片段。忽略目录、隐藏文件和 `__MACOSX` 条目。包最多 2048 个文件、解压后 128 MiB、单文件 32 MiB、单 JS 文件 4 MiB。

```text
example/
  mod.json
  main.mjs
  panel.mjs
  style.css
  data.json
  images/icon.svg
```

```json
{
  "protocol": "rpen-mod",
  "api": 1,
  "id": "example-tool",
  "name": "示例工具",
  "version": "1.0.0",
  "author": "作者",
  "description": "工具说明与会修改的行为。",
  "entry": "main.mjs",
  "dependencies": [],
  "conflicts": [],
  "settings": {
    "toggle-key": {"type":"shortcut","label":"开关","default":"F7"},
    "amount": {"type":"number","label":"数量","default":4,"min":1,"max":20,"step":1}
  }
}
```

必填项为 `protocol/api/id/name/version/author/description/entry`。`author`、`description` 可为空。`name`、`author`、`description`，以及设置的 `label`、`description` 和 `select` 选项文本，都可以写成语言映射（`{ "zh-CN": "…", "en-US": "…" }`），管理器按当前界面语言显示；匹配顺序为完整语言标签、同语种、`zh-CN`、映射首项。`id` 和设置键以小写字母开头，只含小写字母、数字、`-`，最长 64 字符。`version` 必须是字符串，用 `1.0.0` 形式，可有 `-beta.1` 或 `+build` 后缀，不接受语言映射。`entry` 为包内 `.mjs` 或 `.js` ES 模块，必须存在。未知清单字段保留但不自动执行，可用 `x-` 前缀保存扩展元数据。

为兼容 API 1，`api.manifest` 中的名称、作者、说明及设置文本始终是按装载时界面语言解析后的字符串，模组可继续拼接或调用字符串方法。`api.manifestSource` 提供保留语言映射的原始清单副本；类型分别见 `ModManifest` 与 `ModManifestSource`。二者均不改写包内 `mod.json` 或导出内容。界面切换语言后重载模组以重新解析。持久化全局事件的来源名称、作者和版本仍为字符串，类型 ID 和设置键不随语言变化。

可选 `homepage` 表示项目主页。可选 `market` 为市场来源元数据：`{"id":"example-tool","api":"https://example.com/mods/api.php"}`；`id` 应与清单 ID 相同，`api` 是对应市场的 HTTP(S) API 地址。内置市场以完整规范化 API 地址匹配默认更新范围，其实际传输通道仍由市场设置指定。这是来源标记，不是签名或授权；缺少该字段的模组仍可正常导入、启用，也可由用户手动选择检查更新。字段不改变谱面格式或 API 版本。

`dependencies`、`conflicts` 为其他模组 ID 的数组，不允许包含自身。依赖先装载，缺失、循环及双方任何一方声明的冲突会阻止装载。禁用依赖也会禁用依赖它的模组。没有依赖关系时按用户启用顺序装载；自动启动按保存的顺序处理。不支持依赖版本范围，作者应在激活时自行检查功能或版本。

设置类型：

| type | 值与约束 | 控件 |
|---|---|---|
| `boolean` | 布尔值 | 勾选框 |
| `number` | 有限数字，必须声明 `min/max`，可选正数 `step` | 数值框 |
| `text` | 字符串，最长 2000 字符 | 文本框 |
| `color` | `#rrggbb` | 取色器 |
| `select` | `options` 的键；`options` 是“值: 显示名”对象 | 下拉框 |
| `shortcut` | 编辑器快捷键语法，例如 `CTRL&SHIFT&G`、`F8`；空串清除 | 按键录入 |

每项必填 `type/label/default`，可填 `description`。最多 100 项。`default` 必须满足同样的值校验。管理器参数变化会立即保存并通知运行中的模组；不要求重启。快捷键修改立即生效，Backspace 清除。

## 3. 激活、多文件导入与卸载

```js
import { createPanel } from './panel.mjs';
import data from './data.json';
import { fromNumber } from '@rpen/core/beat.mjs';

export function activate(api) {
  api.style(api.package.text('style.css'));
  const panel = createPanel(data);
  api.mount(panel);
  api.commands.register({
    id: 'toggle', title: '显示工具', setting: 'toggle-key',
    run() { panel.hidden = !panel.hidden; }
  });
  api.settings.onChange(({key, value}) => api.log(key, value));
  return () => { /* 还原没有通过托管接口注册的资源 */ };
}
```

入口导出 `activate(api)` 或默认函数，允许异步，返回可选清理函数或 `{dispose()}`。顶层代码在装载时执行，导入包时不执行。每次启用获得独立模块命名空间；静态循环导入遵循标准 ES 模块规则。`./`、`../` 可导入包内 JS/JSON，但不能越过包根；JSON 自动作为 `default` 值，无需 `with {type:'json'}`。支持静态导入、再导出及 `import(variable)`。扩展名必写。

`@rpen/api` 导出 `getEditor()`（等同 `api.editor`）、`getModHost()`（等同 `window.rpenMods`）、`apiVersion`；默认导出是 `getEditor`。`@rpen/core/...mjs`、`@rpen/application/...mjs`、`@rpen/platform/...mjs`、`@rpen/ui/...mjs` 导入编辑器真实内部模块，没有模块白名单。内部源码路径与类方法属于进阶接口，可能随编辑器版本变化。请勿导入 `ui/app.mjs` 来创建第二套编辑器。

包模块由 Blob URL 执行。`import.meta.url` 是 Blob 地址，不能据此拼接素材路径；使用 `api.package.url(path)`。`import.meta.resolve(specifier)` 经包解析器返回可供 `import` 使用的模块标识，不保证返回网络 URL。`api.package.import(path)` 可从包根动态导入，`api.importInternal('core/chart.mjs')` 导入编辑器内部模块。第三方依赖应预先打包成浏览器 ES 模块，许可随包附带。

停用按注册的逆序释放监听、定时器、命令、挂载节点、样式、包内 Blob URL、钩子及托管补丁；`api.signal` 同时中止。提前释放的资源不会再次释放。清理函数应立即恢复可见状态；若返回 Promise，仅观察其错误，宿主不等待网络或其他异步清理完成。异步任务应检查 `api.signal.aborted`，避免停用后继续改写编辑器。

直接赋值、移除原 DOM、网络请求、持久化写入以及已提交的谱面修改不会自动撤销。应使用 `api.patch` / `api.dispose` 或保存原值自行恢复。清理不是事务回滚。卸载不会自动撤销用户已经接受的谱面编辑。

## 4. 通用宿主 API

所有注册类方法返回一个可提前调用、幂等的释放函数，除非表中另有说明。

| API | 行为 |
|---|---|
| `version/id/manifest/editor/signal` | 接口版本、模组 ID、清单、编辑器对象、中止信号 |
| `manifestSource` | 保留多语言文本映射的原始清单副本 |
| `dispose(fn)` | 注册额外清理 |
| `listen(target,type,fn,options)` | 托管任意 DOM/EventTarget 监听 |
| `on(type,fn)` | 监听宿主事件；回调直接接收 detail |
| `emit(type,detail)` | 发出 `mod:<本模组id>:<type>`，避免名称冲突 |
| `hook(name,fn,priority=0)` | 同步可修改的语义钩子，见下一节 |
| `onFrame(fn)` | 每帧回调 `{timestamp,elapsed,chartSeconds,musicSeconds,playing}`；时间戳毫秒、其余时间秒 |
| `onPreview(fn,{target:'preview'})` | 预览画完后回调，可选 `realtime` 背景预览；见第 7 节 |
| `patch(target,key,previous=>replacement)` | 包装方法或替换属性，可按任意顺序停用多个补丁，保留仍启用的补丁 |
| `timeout(fn,ms)` / `interval(fn,ms)` | 托管计时器 |
| `mount(node,parent=document.body)` | 插入 DOM 并返回 node，停用时移除 |
| `style(css)` | 加入 CSS 并返回 style 元素，停用时移除；作者自行约束作用范围 |
| `notify(message,level='success')` / `log(...values)` | 通知、带 ID 前缀的控制台日志 |
| `lockEditing(options)` | 临时阻止普通编辑输入和控件，返回恢复函数，支持多模组与嵌套锁 |
| `settings.get(key)` / `await settings.set(key,value)` | 读取 / 校验并保存清单参数 |
| `settings.onChange(fn)` | 回调 `{key,value}` |
| `storage.read(fallback={})` / `write(value)` / `clear()` | 本模组 JSON 存储，独立于谱面；不要保存巨量二进制数据 |
| `package.files()` / `bytes(path)` / `text(path)` | 包内路径数组、字节副本（缺失 null）、UTF-8 文本（缺失空串） |
| `package.url(path,mime?)` | 素材 Blob URL，停用时回收；常见扩展名自动识别 MIME |
| `package.import(path)` / `importInternal(path)` | 异步导入包内 / 编辑器内部模块 |
| `commands.register(definition)` | 注册可在管理器触发、可绑定快捷键的命令 |

命令必填 `id/run`，可填 `title/shortcut/setting/allowInDialog`。`id` 在本模组内唯一；`setting` 指向清单快捷键参数，优先于 `shortcut`。文本输入、输入法组合及按住重复不会触发模组快捷键。对话框中默认不触发，显式 `allowInDialog:true` 才允许。多个模组绑定相同键时后注册者优先；不要抢占紧急恢复键。编辑器被锁时只有持锁模组的快捷命令可用。

`lockEditing({reason,roots?})` 默认锁住编辑工具、原预览交互和面板，保留模组管理器。模组自己的可交互区域标记 `data-mod-interactive="true"` 可绕过输入拦截。它只锁人机编辑输入，不阻止其他模组、后台任务或联机操作；需要独占环境的工具应自行检查联机状态。`roots` 是要设 inert 的 CSS 选择器数组，替换默认列表；高级模组自行负责覆盖范围。代码层的强制语义禁止可使用提交钩子取消操作。

模组命令接管、`input:before` 标记已处理或取得编辑锁时，会取消正在进行的属性名称拖动并释放指针锁定。普通拖动仅在松手时提交一次；预览草稿不触发提交钩子，最终提交仍经过 `session:before-commit`。草稿期间发生其他谱面提交、撤销或切换谱面时，旧草稿不会覆盖新状态。

桌面本地语音输入在可编辑文本框中处理其按住说话键（默认 `TILDE`），先于普通编辑及模组输入钩子，避免录音键穿透；禁用、只读或 `inert` 控件不触发。Shadow DOM 中的标准文本框通过事件路径识别，设置 `data-dictation="off"` 可对特定输入框关闭此入口。识别结果从原选区插入并触发原生 `beforeinput/input`，不自动发送表单；数值框沿用原有数值更新逻辑，原输入内容发生变化时只提供候选结果。这是 API 1 的兼容补充，不授予模组新的麦克风权限。

## 5. 同步语义钩子

钩子按优先级从高到低执行，同优先级按注册先后执行，共享可变 payload。必须同步修改属性，不等待 Promise；异常会被记录，其他钩子继续运行。避免在提交钩子中递归 `commit`。

| 名称 | payload 与控制方式 |
|---|---|
| `input:before` | `{event,handled:false}`；在编辑器普通处理及模组命令之前同步处理键盘、滚轮、指针按下/释放、鼠标按下/释放、点击、拖放、表单事件；设 `handled=true` 阻止默认行为及后续传播。紧急恢复键优先于此钩子，文本输入应主动豁免 |
| `ui:before-relocate` | `{node,parent,anchor,reason,cancel:false}`；皮肤整理或恢复控件位置前触发，reason 为 `skin-organize/skin-restore`。模组暂存或浮动放置了真实控件时可取消移动；恢复皮肤时可将自己的原位置标记移到 anchor 处并移除 anchor，避免与皮肤反复争抢控件 |
| `session:before-commit` | `{session,label,chart,beforeSelection,cancel,normalizeAlpha}`；可替换数据/标签/选择、设 `cancel=true` 取消、`normalizeAlpha=false` 跳过提交时透明度整形 |
| `session:after-commit` | `{session,label,chart}`；本地提交处理完成后，包括联机提交路径；不代表远端已确认 |
| `chart:parse` | `{text,chart:null}`；可先处理文本，设置 truthy `chart` 则直接返回自定义结果，跳过内置解析 |
| `chart:parsed` | `{chart}`；内置解析完成后改写结果；自定义 `chart:parse` 短路时不触发 |
| `chart:validate` | `{chart,handled:false}`；自行检查后设 `handled=true` 跳过内置 assertChart 检查 |
| `chart:serialize` | `{chart,compact,text:null}`；可替换输入；`text!==null` 直接返回字符串并跳过内置校验和整形 |
| `chart:export-assets` | `{chart,chartName,assets,required}`；PEZ 默认排除未使用文件，在依赖遍历前触发。`chart` 已经过兼容转换，`assets` 为待导出文件 Map，`required` 是需保留的包内路径 Set。模组可用 `required.add(path)` 声明自定义结构或序列化器使用的资源，其 JSON、着色器等依赖会继续追踪；勾选导出未使用文件时不需要筛选，也不触发此钩子。自动保存文件仍遵循通用设置 |
| `preview:before` | `{chart,seconds,lineIndex}`；在预览/背景预览绘制前替换渲染数据、谱面秒数和当前线，不修改存档 |

事件取样及属性拖动可以使用临时谱面和循环预览时间，因此预览钩子、`onPreview` 和渲染包装函数应使用回调传入的 `chart/seconds`；它们不一定等于已提交谱面和实际播放头。`onFrame` 的 `chartSeconds/musicSeconds` 仍表示实际播放时间。以上行为沿用 API 1。

原有 RPEN 导出路径有自己的排序、兼容转换和媒体打包流程。`chart:serialize` 对所有调用该函数的路径生效，但不是任意文件格式流水线的万能拦截点。要完全替换导入、保存、兼容导出或预览算法，可以包装相应实例 / 类原型，或者实现自己的按钮及流水线。

```js
export function activate(api) {
  // 为所有未来提交加自定义字段，仍使用编辑器的撤销记录。
  api.hook('session:before-commit', change => {
    change.chart = {...change.chart, 'x-my-mod': {enabled:true}};
  });
  // 实例、类原型均可包装；this、参数和返回值由模组显式保留。
  api.patch(api.editor.timeline, 'draw', previous => function(...args) {
    const result = previous.apply(this, args);
    // 在时间轴追加自己的绘制。
    return result;
  });
}
```

`LineRuntime` 等内部导出必须参照当前源码核对路径和签名。上面的扩展点是示例，宿主没有把可包装的对象限制为这些实例。

自定义格式示例：

```js
import { createChart } from '@rpen/core/chart.mjs';
export function activate(api) {
  api.hook('chart:parse', input => {
    if (!input.text.startsWith('MYCHART\n')) return;
    const chart = createChart();
    chart['x-custom'] = JSON.parse(input.text.slice(8));
    input.chart = chart; // 保留标准骨架，可继续使用现有面板和预览。
  });
  api.hook('chart:serialize', output => {
    if (output.chart['x-custom'])
      output.text = 'MYCHART\n' + JSON.stringify(output.chart['x-custom']);
  });
}
```

可以取消内置校验并使用完全不同的数据结构，但必须同时接管依赖该结构的时间、面板、预览、保存及兼容导出。宿主不会自动让旧编辑器理解未知字段或未知语义。建议用命名空间保留扩展字段，给用户明确的兼容导出策略。

## 6. 编辑器对象

`api.editor` 是有实时 getter 的对象：每次使用时读取当前 session/chart，不要长期缓存进入另一个谱面前的引用。时间单位和坐标必须明确：

- 拍数是 `[整数,分子,分母]`；数值拍数用 `@rpen/core/beat.mjs` 的 `fromNumber/beatValue` 转换。
- `audio.time` / `musicSeconds` 是音乐秒；`chartSeconds()` 是谱面秒，二者关系为 `音乐秒 = 谱面秒 + offsetSeconds()`。`META.offset` 单位毫秒。
- 判定线使用中央原点、X 向右、Y 向上的谱面坐标。预览屏幕像素 Y 向下，线旋转为顺时针正。不要忽略父线、事件层、锚点、缩放、BPM、摄像机与视野比例。

读取属性：`session/chart/tempo/assets/preferences/editorPreferences/chartName/hasDocument/home/activePane/dirty/libraryProject`。`loop` 可读写。`assets` 是路径到字节的 Map；通过 `addAsset/removeAsset` 修改可正确标记未保存。

`editor.speedCurve` 是按需创建的调速曲线面板，`active` 标识是否展开，`close()` 取消未完成预览并关闭。它只修改目标线的 `speedEvents`，不修改音符 `speed`；拖拽作为单次事务进入撤销历史。“后段缓动”直接描述当前节点到下一同层节点的距离曲线（恒速为 1），切换时固定两端距离。默认判定锚点固定，真实速度节点可与其重合；模型保留 `judgment` 标记，`ref()` 优先返回真实事件引用，仅没有真实节点时返回 `edge: 'judgment'`。重合节点可修改拍数/后段缓动、拖出及删除，距离遵守判定约束；从一侧移入时保持另一侧速度，默认锚点不会被删除。末节点没有后段缓动。实现优先用原生单事件，否则每个区间最多用 64 段正时长速度事件拟合（距离误差容限 max(0.2, 两端距离差绝对值 × 0.0015)）。显式分界携带 `rpeNextSpeedCurveNode` / `rpeNextSpeedCurveEndNode`；`rpeNextDistanceCurve` 的版本 1 分组记录含 id、start/end、easing、count 和 native 形状签名，完整有效时隐藏内部拟合接点。外部改变原生事件后会重新识别。以上字段不改变事件求值或积分，未知字段保留规则适用。位置、尺寸、缩放、时间范围（相对判定拍）和吸附步长由本地偏好保存，不写入谱面。

| 方法 | 用途 |
|---|---|
| `commit(label,chart)` | 按编辑器提交途径产生可撤销修改，传入新对象，不原地改旧历史 |
| `replace(chart,name?)` | 替换当前谱面并建立新编辑上下文；不是普通可撤销编辑 |
| `chartSeconds()/offsetSeconds()/currentBeat()` | 当前谱面时间、延迟秒、数值拍数 |
| `seek(seconds,{music:false,pause:true})` | 默认按谱面秒定位，music=true 按音乐秒；默认暂停 |
| `seekBeat(beat,pause=true)` | 按数值拍数定位 |
| `selectLine(index)` | 选择从 0 开始的线号索引并刷新 |
| `setPreview(visible,{stay:true,autoplay:false})` | 切换预览界面，不隐式播放 |
| `play()/pause()` | 播放（异步）/ 暂停 |
| `beginPreviewSession()` | 暂停并结束正在进行的放置/取样，暂存视图参数，进入全线预览并开启详细碰撞几何；返回幂等恢复函数，恢复时暂停，不回退时间、不改谱面 |
| `activatePane(name)` | 进入右侧页面，例如 `chart/notes/events/lines/noise`，具体名字见 index.html |
| `invalidate()/render()` | 请求重新绘制 / 同步刷新编辑控件 |
| `save()` | 调用现有主动保存流程，返回 Promise；必须 await 并处理写入或版本冲突错误，详见下文 |
| `addAsset(path,bytes)/removeAsset(path)` | 改素材、标未保存、刷新贴图缓存 |

可直接访问实际对象：`audio/audioSources/audioOnsets/audioAnalysis/playback/preview/realtimePreview/timeline/skin/images/hitSounds/editorSkins/noteSkins/noiseEditor/eventSampler/spatialTool/trajectoryPanel/textLinesPanel/noiseFitPanel/noiseTrackingPanel/multiEdit/batchControls/collaboration/versionControl`。它们不是只读快照或受限代理，可以包装方法、调整字段或替换底层行为；具体接口看同名源码。持久设置修改需调用相应的保存流程。`audioOnsets`管理采音算法、模型推理缓存与候选筛选，供原生界面和AI共用；调用`analyze(buffer, options, signal)`不修改谱面，模型环境需由用户配置，不能绕过其安装确认。

几何投影扩展可在预览 renderer 上提供 `spatialMapping.project(point, seconds, frame, chart, tempo)` 与 `unproject(...)`。point 是完成比例适配和父线计算后的判定线世界 X/Y，输出仍为当前预览面中的同单位 X/Y；frame 包含 CSS 像素 width/height 和绘制 scale。返回 null 表示不可投影或不可反算，不能伪造零坐标。空间轨迹按各节点自身的秒数调用映射，编辑时先反算观察视图，再调用 unproject。内置摄像机已接入，停用模组时恢复原映射；纯像素 Shader 无需提供此接口。

音频分析的 `audioSources.select(id或id数组)` 临时切换实际播放与默认分析音源，至少选择一项；`selectedIds` 返回勾选项，`resolveSelection()` 返回其混合。`audio.buffer` 始终保留原音乐，`audio.playbackBuffer` 是当前实际播放缓冲；两者不可混为保存或导出的素材。所有声部共用原音乐零点与谱面延迟，选择不进入谱面历史或设置，退出谱面恢复原音频。波形/频谱按各声部颜色分列显示，`audioOnsets` 默认分析当前混合。

`editor.raw` 提供更底层入口：实时 `session/chart/assets/tempo`、`renderSession/replaceChart/activatePane/togglePlayback/togglePreview/save/applyDisplaySettings/persistEditor/setHome`。`raw.chart=` 直接替换历史当前文档并通知，**不增加撤销记录**；`raw.tempo=` 更新时间轴 TempoMap。其他内部一致性由作者负责，优先使用普通 commit。可以通过任意 DOM/Web API、内部 ES 模块、类原型与这些入口继续扩展，宿主不限制为本节列出的功能。

多线表达式可包含 `all`、`@notes`、`@events`（不区分大小写），后两者按当前编辑时间视野筛选音符或当前层事件，包含跨屏 Hold 和 BPM 倍率；空格分隔词元取并集。这些词元不能作为组名。`editor.timeline.setMultiLineExpression(text)` 解析并设置表达式，之后启用多线即可动态刷新；`session.multiLineExpression` 保留表达式，`multiLineIndices` 是当前解析结果，可能为空，此时多线模式仍保持开启。手动改选线号会结束动态表达式；拖拽、框选或放置过程中保持列不变。`timeline.multiLineEventVisibility` 是按事件类型名索引的展示布尔值映射，未设置视为展示；仅影响多线事件模式，`timeline.eventTypes` 与 `eventColumnBounds()` 返回当前可见栏及坐标，隐藏栏不参与取样命中、框选和放置，不改动谱面数据。

`editor.directPlacement` 是直接放置面板实例，属于进阶实现接口：`active` 表示是否展开，`open(lineIndex)` 在预览中展开当前线的音符编辑区，`close()` 关闭。它复用原 `editor.timeline` 与音符画布，通过 `timeline.noteView` 映射指针和绘制坐标，临时停用多线编辑，关闭后恢复；扩展交互应调用时间轴的 `point/noteHorizontal/notePositionAt/vertical`，不要直接用旋转后的 DOM 外接矩形换算。音符横坐标不限制在 −675～675。`beginPreviewSession()` 会先关闭直接放置和重合线列表。

`editor.quickCurve` 与 `editor.noteTrackingPanel` 是进阶实现入口。单选音符长按中键进入曲线填充时，数字键和 Q/W/E/R/Esc 由临时交互消费，Shift+中键及短按仍保留框选；生成前只使用临时预览，不增加历史。音符追踪通过 `note_track` 命令或原生临时页面生成普通事件，默认使用当前线和当前事件层，不新增谱面字段。`timeline.noteSpacing` 为持久化横向间距比例，默认 1；扩展拖拽应调用 `horizontalScale/notePositionAt/noteHorizontal`，不要假设可见横坐标固定为 −675～675，也不要用此比例调整贴图大小。`timeline.notesOnlyNoteScale` 为单线仅音符视图的视觉缩放，默认 0.9；`referenceNoteScale` 保持坐标布局基准，实际音符宽高使用 `renderNoteScale`。

右键默认值面板为 `editor.placementDefaultsPanel`。`editor.session.noteDefaults` 仅属于当前编辑会话，退出谱面时重置；`lineEventDefaults` 由编辑器偏好层跨谱面和重启保存。创建物件时可调用 `session.createNote(type, beat, positionX, endBeat?)`、`session.createLine(name?)` 使用这两组默认值，返回物件后仍须正常提交。默认值不写入谱面、不占用撤销历史，也不自动改动导入、复制或已有物件。底层 `core/chart.mjs` 的 `createNote/createLine` 继续返回固定的格式默认值，适合导入和明确控制属性的算法；两组构造入口不要混淆。`ensureLineCount(chart, count, lineEventDefaults?)` 的第三个参数可将同一套默认值用于批量新线。

`editor.diagnostics` 提供后台谱面检查。`await diagnostics.waitBasic()` 等待当前版本的基础结果，`diagnostics.issues` 为基础与已完成深度结果的合并列表，`pending/running/progress/deepComplete` 表示状态；`change` 更新结果，`progress` 只更新进度。常规选择和播放循环不应调用同步整谱 `diagnose()`。`startDeep()` 仅在用户主动请求时调用，再次调用取消；谱面、素材、模组、目标或比例变化使深度结果失效。基础 Worker 使用结构共享的增量补丁，不传输音频/图片内容。

`missingBaseline` 为自动警告，仅检查判定线第 0 层的五个基础事件轨道。轨道没有开始拍不晚于 0 的有效事件时产生一项结果；零拍前已经结束的事件和零拍瞬时标记也能提供初始值。结果通过 `line/layer=0/eventType/path/beat=0` 定位缺失的栏，没有物件 `index`、不可删除；上层事件和扩展轨道不补足第 0 层。检测与轨道常规校验共用遍历及缓存。

全局事件校验读取注册列的 `valueType/min/max/overlap` 和模组来源，缺失模组与来源、版本变化会显示提示。深度检查还在独立 Worker 执行列的 `validate(event)`：应使用可独立执行、不依赖 DOM 或外部闭包的函数，可返回 `false`、错误字符串或抛出错误；支持异步返回。修改返回的谱面副本不会写回编辑器。依赖主线程闭包而无法运行的校验器会明确显示未能独立校验，不会当作检查通过。一般 Shader 重叠和合法瞬时事件仍然允许。深度位置检查复用场景、父线、倍率、视窗比例与内置三维摄像机投影；任意自定义后处理 Shader 的像素扭曲不属于几何位置判断。

放置区使用 `noteView.flow` 将秒数映射为速度积分距离，`noteView.sideAt(y)` 返回上区 1 / 下区 -1；`timeline.timeAt(y, side?)` 反算拍点时间，`timeline.noteVertical(note, endpoint='startTime')` 按音符的 above 和首尾拍计算绘制位置，`vertical(beat,height?,side=1)` 可显式选择区。零速/反向段保留可编辑的单调距离轴；与实际预览有偏差时绘制对应连线，不改谱面数据。`preview.noteOpacity` 只乘音符本体透明度，展开期间为 0.3，退出恢复原值；`preview.noteCenterLine` 与 `preview.noteCenters` 仅收集目标线已绘制音符的中心几何，避免额外遍历全部谱面。以上为进阶实现接口，不增加协议版本。

普通音符与放置面板拖拽时，`editor.timeline.previewNotes()` 提供临时的 `Map<线号, Map<音符索引, 音符>>`（无草稿时为 null），不改已提交谱面或撤销历史。原生预览通过 `preview.noteOverrides`、`preview.noteDraft` 对受影响音符增量绘制，保留其余场景索引；包装原生 `drawScene` 的模组会沿用此效果。完全自行绘制音符的模组需自行读取草稿。松开提交或取消后草稿撤回，谱面格式不变。

### 6.1. 保存、个人设置与平台存储

模组应通过 `api.editor.commit` 修改当前谱面，通过 `addAsset/removeAsset` 更换素材，再用 `await api.editor.save()` 保存。保存不冻结编辑；调用后发生的新修改仍可能处于未保存状态。重复调用会在需要时排队写入更新的快照。`ProjectConflictError` 表示库内项目已被修改或删除，不能通过清空 `storageRevision` 等方式强制覆盖；应保留当前编辑，让用户导出 PEZ 或另存项目。自动保存生成独立恢复副本，不覆盖谱面库项目，没有新修改时不会重复备份。

`api.storage` 用于本模组的个人 JSON 数据，不属于谱面，也不随谱面 JSON/PEZ 或模组包导出。`write/clear` 保持同步调用形式；网页端写入同源本地存储，桌面端先更新内存再排队安全写入原生文件，返回不表示磁盘已写完，`await api.storage.write(...)` 也不产生额外落盘保证。`settings.set` 的 Promise 表示校验与参数更新完成；桌面持久化同样由后台队列处理。后台失败会报告并保留可重试值，正常关闭桌面窗口前会等待设置写入。模组激活、停用及页面重载时，应遵守异步任务清理约定。

桌面端的导入包位于所选谱面库的 `mods`，启用列表、参数和个人数据位于 `preferences`；固定的桌面配置记录库位置，因此同一用户更新或移动程序后自动沿用。切换到另一个库时使用那个库的包与设置，不能假定任意库共享个人数据。网页端、不同同源地址和桌面库相互独立。需要随作品分享的内容应放入有模组命名空间的谱面字段或全局事件，并说明停用及兼容导出策略。

进阶模组可导入 `@rpen/platform/library.mjs`、`recovery.mjs`、`mods.mjs` 等业务接口。这些接口会按运行环境选择后端；不要直接操作固定名称的 IndexedDB、localStorage 键、SQLite 或原生版本文件，否则桌面数据可能不生效，也可能绕过冲突检测、素材引用和恢复逻辑。`libraryProject.id`、`storageRevision` 和素材哈希都是存储标识，不是目录名或可访问的文件路径。桌面“打开谱面所在文件夹”通过主进程解析已保存项目，未提供通用文件系统权限。

### 6.2. 谱面版本控制

谱面版本历史与撤销栈、谱面库保存、自动恢复副本各自独立。完整行为及仓库包约定见[谱面版本控制说明](CHART-VERSION-CONTROL.zh-CN.md)。`editor.versionControl` 是当前版本控制面板实例，属于可包装的进阶实现接口，`await editor.versionControl.open()` 读取当前谱面的版本库；打开可见页面可用 `editor.activatePane('version-control')`。需要数据级操作时可导入 `@rpen/application/chart-vcs.mjs` 的 `ChartRepository` 与 `@rpen/platform/version-store.mjs` 的 `openVersionStore()`，不要绑定某一平台的存储目录或数据库名。这些内部方法不属于 API 1 的稳定方法契约，调用前应确认实例存在并 await 操作。

快照记录当前谱面 JSON、素材和素材文件夹，保留模组命名空间与全局事件来源信息；快照存储使用保留数值的原始 JSON，不调用导出专用的 `chart:serialize` 钩子，读取时经过 `parseChart` 和现有解析、校验钩子。读取旧版本后会重新创建编辑会话，`editor:chart` / `editor:state` 会通知会话和谱面引用变化；模组应重新读取 `editor.session/chart/assets`，不要继续修改旧引用。恢复结果保持未保存，用户需要再保存到谱面库。模组个人设置、启用状态和模组安装包不属于谱面快照。

合并对内置判定线父子关系和根级 shader 所属线进行身份映射，临时身份不写入谱面。未知模组字段按 JSON 三路合并；结构相同不代表自定义语义一定可合并，自定义线号引用、跨事件约束和外部数据不会自动获得语义重映射。模组可通过现有 `chart:validate` 校验合并结果，或包装版本库方法提供自定义合并；不应将格式转换仅放在 `chart:serialize` 中。模组全局事件仍须保留来源信息，停用模组不会删除历史中的扩展数据。本节为 API 1 的兼容补充，不改变现有钩子或升级 API 版本。

## 7. 事件与预览

`api.on` 监听：

| 事件 | detail |
|---|---|
| `editor:state` | `{session,chart,playing,home,pane,lineIndex,dirty,previous}`；每帧比较，变化时发出，首次也发出 |
| `editor:chart` | `{session,chart}`；谱面引用或会话变化，包括撤销/重做 |
| `editor:time` | 与 onFrame 同形，音乐位置变化时发出 |
| `editor:save-started` | `{}`；主动保存开始 |
| `editor:save-succeeded` | `{message}`；完成一个主动保存快照，不保证此刻没有更新的未保存修改 |
| `editor:save-failed` | `{error}` |
| `mod:loaded` | `{id}` |
| `mod:unloaded` | `{id,reason,error?}`，reason 为 `disabled/error` |
| `mod:<id>:<自定义名称>` | 另一个模组用 emit 发送的内容 |

`onFrame` 不受编辑器绘制节流影响，仍受浏览器实际帧回调、隐藏窗口和主线程负载影响。`elapsed` 单位秒，暂停播放时仍会回调。不要在每帧 commit 大谱面。计算密集任务可自己使用 Worker（受 CSP），用 signal 中止。

`onPreview` 回调 `{renderer,target,chart,tempo,seconds,timestamp}`，发生在判定线、音符、UI、噪域及 shader 画完后。可以操作 renderer.canvas，或挂一个独立 canvas/DOM 覆盖层；自己 save/restore 画布状态，并考虑设备像素比。`renderer.viewport` 是 CSS 像素的可视画面矩形；`viewScale` 将谱面坐标换为 CSS 像素。视口中心与整个居中画布中心一致，但鼠标要减去 canvas 的 getBoundingClientRect 原点。

详细碰撞几何是可选的，`renderer.collisionGeometry=true` 才生成额外数据；普通编辑保持关闭。`noteHitAreas` 含线号/音符索引、头尾屏幕坐标，开启后普通音符带 polygon、collisionWidth/collisionHeight/rotation，Hold 用头尾线段和宽度形成身体。几何在绘制坐标系内、单位 CSS 像素，不含 shader 扭曲后的像素变形。`renderer.noisePreview.hitEntries` 提供当前可见层的噪域世界四边形、area、state；state 为 `active/ready/disabled`，world 点仍需中心平移、Y 翻转及 viewScale。不同噪域层独立合成，反转规则要与核心一致；直接把四边形当独立实心块会误判洞。

`editor.skin.noteScale(highlight)` 返回当前资源包普通 / 高亮音符的贴图尺寸倍率；默认皮肤为 1。自定义点击范围或剔除边界时应计入此倍率；`skin.head` / `skin.hold` 绘制时会内部应用倍率，传入绘制宽度时不应再次相乘。

密集音符可由编辑器批量提交绘制，仍保留逐个音符的取样与碰撞信息，以及原有的绘制顺序、透明度、头尾和图集参数。内置绘制器通过 `skin.noteBatchCompatible` 表明可批量绘制；覆盖 `head` / `hold` 的模组和使用重复 Hold 身体的皮肤自动沿用原 Canvas 路径。模组不得仅为启用优化而把自定义绘制器声明为兼容；批量上下文只实现标准音符绘制所需的图片、矩形和矩阵操作。设备不支持或批次失败时会重新用原路径绘制当前批次。

进阶绘制接口中，`LineRuntime.noteState` 的 `size` 为宽度倍率，`sizeY` 为不含音符自身 `size` 的高度倍率；尺寸控制曲线仍作用于两轴。`RpeSkin.head` 在既有 `minimumHeight` 后可接 `heightWidth`，`hold` 在 `color` 后可接 `heightWidth`，表示计算贴图高度的基准宽度，省略时沿用传入宽度以保持旧调用兼容。`hold` 在 `heightWidth` 后还可接 `zeroDirection`（默认 `1`），仅在首尾坐标相等时决定头尾贴图的朝向；预览自绘应按音符原始上下侧传入，上方为 `1`，下方为 `-1`，避免零长度 Hold 的两侧尾贴图重叠。模组自绘或生成碰撞框时应使用两轴各自的倍率。判定线 `anchor` 是左下原点的归一化纹理锚点，图片和文本共用；线坐标及音符判定位置不因它移动。`bpmfactor` 文件语义仍为拍时倍率，面板的“BPM 倍率”显示其倒数，读取谱面时不可再把字段倒置一次。

## 8. 示例、恢复与兼容

性能监控默认通过 F10 开关，可在快捷键设置中修改。关闭时不启动采样定时器或桌面硬件工作线程；开启后只记录实际编辑器绘制帧，按低频率更新图表与硬件指标。网页端不具备系统 CPU/GPU 查询权限，不可用指标显示 `—`；桌面端 CPU、应用内存与系统内存由原生接口提供，NVIDIA 驱动工具可用时优先读取 NVIDIA GPU/显存，其他 Windows 设备使用系统性能计数器（GPU 取最忙引擎）；这些硬件读数不代表仅编辑器的用量。应用 CPU 以整机逻辑处理器总容量为 100%。测试从音频零秒开始，保持当前播放倍率和预览设置，暂时跳过循环区间；停止、退出预览、切换谱面或隐藏窗口时均保留截至当时的统计。模组正常的预览绘制钩子仍参与测试，监控不改变谱面数据。

内置“星航 · 谱面躲避”展示预览覆层、快捷键、临时编辑锁、几何碰撞、音效、成绩存储及完整恢复；“像素矿工”展示控件移动、布局恢复、动画与音效；“三维摄像机”展示全局事件、透视渲染和三维交互；“Nyamon 模组市场”展示网络请求、安装审阅、取消与恢复副本。它们都是普通 `mod.json + ES module` 包，使用同一加载器，可导出查看和派生。

内置“像素矿工”展示提前输入拦截、真实控件的暂存/放置、九格物品栏、掉落与经验动画以及恢复。默认 F9 开关工具状态，Ctrl+Shift+F9 恢复全部；1–9 选栏位，文本框输入和滚轮保留原行为。关工具状态保留挖掘结果，停用模组才全部恢复。经验球先受重力落地，停留半秒后飞向鼠标；控件掉落物使用方形边框。控件暂存期间会拦截皮肤重新整理，面板按同一 ID 或同一表单语义字段重建控件时更新持有的真实控件，避免自动补回。控件状态仅在本次页面有效；没有稳定标识的自定义控件，或切换谱面后含义变化的控件，应恢复后重新操作。与星航声明冲突，避免同时接管输入。

星航默认 F8，可在管理器修改：从当前音乐位置开始；关闭介绍后鼠标进入画面才播放。音符和 Hold 身体为障碍；**仅 active 噪域参与碰撞，ready/disabled 均不参与**。各噪域层分别处理普通覆盖及反转。五颗心，受击无敌，移出暂停、移回扣心；星星、连击、随机修复补给和结算均由模组实现。关闭或停用恢复原界面并暂停，不写入谱面。

托管回调第一次错误会通知，累计 5 次会停用该模组及依赖它的模组，保留错误说明；可修正后手动启用。不要把异常捕获视为隔离：同步死循环无法被页面自己的计时器或热键打断。

恢复途径：

1. 管理器中禁用单个或全部模组；运行中仍可打开管理器。
2. `Ctrl+Alt+Shift+F11` 紧急禁用全部；只恢复托管资源。
3. 重载地址末尾加 `?mods=off`（已有查询时用 `&mods=off`）本次不装载模组，再到管理器排查。桌面版可从开发者控制台执行 `location.search='?mods=off'` 后重载。
4. 如果上次在激活途中被关闭，下次会跳过自动装载并提示。严重死循环需先关闭窗口，再以恢复地址启动；桌面启动可用 `--mods-off`。

API 1 的托管方法、清单和钩子是稳定契约；新增可选字段与钩子可兼容加入。对内部类、DOM 结构和 raw 流程的依赖需要随编辑器版本验证。API 不兼容时宿主拒绝装载，不悄悄执行。模组作者应注明测试的编辑器版本、是否改变格式/语义、与联机的兼容性以及停用后需不需要重载。协议没有模组签名、网络权限白名单或进程级隔离；内置市场仍执行本节的信任与恢复规则。

## 9. 制作与测试

### 全局事件扩展

`api.globalEvents.register(definition)` 可向原生全局事件工作区注册多种事件，每种允许多列、指定列宽、自定义 JSON 值、校验、绘制、属性控件和快捷数值操作。`list/read/replace/open` 提供查询、事务编辑和打开页面；停用注销实现并保留谱面数据。**持久化模组全局事件必须在谱面中声明来源模组 id、名称、作者、版本；推荐用“模组名 + 作者名”命名类型。** 托管接口自动从清单写入来源，自行修改原始结构时也必须遵守。

详细格式、示例和生命周期见 [全局事件协议](GLOBAL-EVENTS-PROTOCOL.zh-CN.md)，类型声明见 `schemas/mod-api-v1.d.ts`。全局事件不绑定当前判定线，实际语义仍由提供方通过通用模组接口扩展。

内置“三维摄像机”用七列数值事件驱动透视相机，包含专属属性控件、拖拽取样、实时过渡助手和七列原子事务；[完整说明](../assets/mods/spatial-camera/README.zh-CN.md)记录坐标、求值及序列化约定。它通过 `api.patch` 扩展两个 `Preview` 实例的 `drawScene(context, chart, tempo, seconds, selectedLine, frame)`：该独立世界绘制阶段位于背景之后、第一层 shader 之前，frame 含 width/height/viewport/scale/divisor/states。可选 center 为捕获窗口世界中心，默认 (0,0)。噪域的 `transformGeometry(entry, frame)` 在状态求值后、各层合成前变换点集，frame 含 width/height/scale/viewport/seconds，返回 null 可裁掉几何。两者均属进阶实现接口，模组应托管恢复补丁，保持“谱面物件 → 第一层 shader → 游戏 UI → 噪域 → 第二层 shader”的原有顺序；不要在几何变换中改写激活或反转语义。

在项目目录执行 `node tools/pack-mod.mjs <模组目录> [输出.rpenmod]`，会校验清单和 JS 语法并打包。也可将文件直接 ZIP 打包；不要含用户谱面、密钥、开发日志或 node_modules。测试时使用备份谱面和独立浏览器或桌面数据目录；桌面测试还应使用独立的谱面库，不能只更换程序文件夹就假定数据隔离。

`Preview.drawBackground`、`Preview.drawUi` 使用同样的绘制阶段签名，分别位于背景阶段及第一层 shader 后的游戏 UI 阶段。前者支持 center 捕获窗口偏移；后者使用 frame.viewport 定义 UI 的逻辑布局范围，并依赖 frame.states。三维摄像机的“跟随谱面”选项组合这两个可恢复补丁，让背景图片和游戏 UI 参与投影，同时保留它们在 shader 与噪域前后的顺序。

替换谱面内 Shader 资源字节后，可调用 `editor.shaderAssetsChanged()` 标记素材未保存、更新谱面检查与预览源码缓存，避免无关图片重载。资源字节应替换为新的 `Uint8Array`，不要原地修改旧对象；此接口只负责素材变更通知，不创建编辑事务或自动联机传输。

发布前至少验证：导入后不执行、启用及再次启用、修改快捷键、文本输入不穿透、切换谱面、撤销/重做、禁用时清理、依赖/冲突和异常恢复；自定义数据还须验证保存、重开、Next 导出及兼容导出的行为。支持桌面端的模组还应验证更新后设置继承、切换谱面库、大素材保存、冲突或写入失败时保留编辑。替换素材优先提交新的字节数组；保存仍会重新校验可变数组内容，不以对象引用相同作为素材未变化的保证。高自由度来自同页执行能力，可靠性来自模组作者对状态与恢复的完整管理。

编辑器更新入口位于设置的“关于”，更新包的选择、下载、校验与程序替换由宿主负责，没有新增模组安装权限。模组应将用户数据保存至既有谱面、设置或工作区接口，不要写入程序安装目录，也不要依赖安装目录保持不变；宿主重启更新沿用正常的保存、设置写入与关闭流程。

事件可包含 customEasing，具体见 ANIMATION-CURVES-PROTOCOL.zh-CN.md 和 schemas/animation-curve-v1.schema.json。提供方应使用共用 EventTrack / event-easing 求值，不能只读取 easingType。修改标准缓动须移除 customEasing；未知字段与裁切区间应保留。模组类型声明增加 AnimationCurve / CustomEventEasing。

视频渲染模块创建独立 Preview，沿用 preview:before 和 onPreview 的传入 chart/seconds，payload.purpose 为 autoplay/export；离线输出不依赖真实播放头。需要包装渲染实例的扩展可从 @rpen/ui/render-extensions.mjs 导入 registerRenderExtension(attach)，attach 返回释放函数；同时保留原编辑器实例的接入。三维摄像机已使用此机制。详见 VIDEO-RENDER.zh-CN.md。

内置 `rpe-classic-layout` 与同版本 RPE Classic 编辑器皮肤配套：选择皮肤时自动装载，切换其他皮肤时卸载，自动装载不改写普通模组的持久化启用列表。手动停用及紧急禁用有效，安全模式不自动装载；手动启用会应用配套皮肤。皮肤与布局更新均随本体分发，保持导入包不能覆盖内置版本的规则。后续该皮肤的外观适配由维护方验证。实现使用现有 API 1，不增加对普通扩展的权限或接口要求。
# RPEN 视频渲染模块

唯一用户入口为顶部右侧 `#render-video`“渲染”按钮；在谱面库首页禁用，不增加卡片动作、侧栏、工具栏或快捷键入口。UI、场景和编码模块按需动态加载，不注册模组，也不使用全局 DOM MutationObserver。

## 数据和时间

`src/application/render-project.mjs` 从当前谱面捕获只读副本和素材引用。普通谱面采用完整 chart；超大谱面采用完整磁盘文档的 header、revision、区间 window、hits 和 soundNames。窗口不作为完整数据源，不展开重合组。磁盘 revision 改变时明确终止，不能继续混用两个版本。

画面、音符、打击音效和输出区间均使用**谱面秒**。音乐位置 = 谱面秒 + 有效 offset / 1000。修改面板中的偏移只改变音乐读取位置，不移动音符与打击音效。音乐时长扣除偏移后用于自动终点；明确的 `META.duration` 优先。无音乐时遍历音符、普通与特殊事件、噪域、全局事件的实际时间字段，排除遥远的状态延续哨兵时间。

窗口接口 `soundNames` 返回当前磁盘文档的去重音效名（包含 tap/drag/flick），最多 512 种，用于预先解码和计算音效尾音范围。`hits` 是谱面秒、半开区间，返回的 count 为实际重合数量。混音按 count 加权，不创建 count 个对象，不使用整段 8192 次截断。

## 参数和皮肤

`schemas/video-render-settings-v1.schema.json` 描述本机偏好。设置不写入谱面，不进入谱面撤销。区间打开时重置；其他偏好持久化于 `rpen-render-studio-v1`。任务开始时冻结参数，禁用参数表单，并独立创建最终分辨率的场景。实时预览的分辨率与输出分离，最大 1280×720。

`skinPolicy` 默认为 `render`：渲染器控制打击粒子，保留所选皮肤的音符和命中贴图。`skin` 尊重皮肤自身的粒子隐藏、时长、尺寸、旋转和着色规则。全局关闭打击特效仍优先；皮肤信息不会写回或临时污染编辑器共享记录。音效优先级为谱面同名素材、所选皮肤、内置声音；不借用编辑器的旧皮肤缓存。

默认渲染策略的打击粒子采用 PR #34 的参数：扩散半径系数 `1.1×0.85×1.3×1.03`、尺寸系数 `0.0907×1.05`，寿命 `2/3` 秒、数量 4；外扩采用 `render-particles.mjs` 的有理函数，透明度为 `1-progress`，从寿命的 40% 开始按 sine-in 收缩，幅度 `0.253×1.15`（29.095%）。命中贴图仍以音符尺寸的 1.4 倍绘制，默认 31 帧、每帧 0.015 秒，资源包动画沿用所选皮肤。渲染面板预览与视频导出共用这些参数，普通编辑器播放和 `skin` 策略沿用各自原有特效。保留现有完整命中枚举及批绘制，不引入模组旧版的固定数量截断。

打击特效与普通播放共用 `Preview.drawHits` 的命中枚举、位置缓存、视口裁剪和 GPU 批绘制。`render` 仅提供粒子外观、完整寿命及保守绘制半径；`skin` 直接沿用普通播放的皮肤特效路径。密集区间不按固定总数量截断特效，避免旧粒子占满名额、遗漏后续新打击；视口裁剪不得遗漏边缘仍可见的贴图或粒子，批绘制失败回退 Canvas 路径。

噪域在普通预览与视频渲染中共用 `previewNoiseGeometry`：中心按舞台横纵比例适配，角点相对中心先旋回局部坐标、按自身横纵轴缩放、再旋回，保持旋转角和矩形形状。之后再执行 `NoisePreview.transformGeometry`（如三维摄像机投影），不覆盖已有钩子；窗口外复用已变换几何时不重复缩放。噪域取样的轮廓、角点及事件值反算使用同一显示变换，锚点仍表示绝对舞台坐标；谱面本体的事件、积分及坐标语义不变。

`render-studio/noise.mjs` 只在渲染实例上启用 `NoiseSkinRenderer` 的 `overlay:true`，并为未指定皮肤的噪域层补入内置 NoiseField；补入信息仅保存在缓存的渲染副本，已有皮肤优先，不写入原谱面。overlay 保留一张原始场景纹理，计算皮肤结果与原图的 RGB 最大通道差，用 `smoothstep(0.003,0.022,delta)` 作为混合权重，再以预乘透明度叠加；小色差效果会被削弱。普通编辑器预览保持默认 `overlay:false` 的整帧替换，不使用颜色差过滤，也不自动补入默认皮肤。

## 编码与输出

Mediabunny 1.65.0 为未修改的官方 npm 浏览器模块，固定版本、来源、源码提交和校验值见 `assets/vendor/mediabunny/UPSTREAM.json`，MPL-2.0 及源码取得地址随程序分发。

`src/platform/video-encoder.mjs` 在逐帧前等待数据和资源就绪，按固定帧率写入，末帧缩短至所选区间终点。音频按最多一秒的 PCM 块混合，跨块保留音效尾部，按时间与视频交错写入；不分配整段离线混音或整段压缩视频缓冲。所选容器无法编码预期音频时明确失败，不能自动变为无音轨视频。

`src/application/render-frames.mjs` 负责跨平台帧调度。`CanvasSource.add` 同步捕获当前画布后，仅允许下一帧的绘制与当前帧编码重叠；下一次送帧仍须等待编码器和文件输出的背压，不累积帧队列。缺少同步 `VideoFrame` 快照能力时自动采用顺序绘制。分辨率、帧率、编码质量、所有帧时间戳、音效与混音算法保持相同；不通过改变编码器质量模式加速。

编码任务的 `drawFrame(time,index,frames,signal)` 只负责准备和绘制输出画布；独立的 `onFrame` 回调提供实际编码画布，面板预览和进度按墙钟最多约每 100 ms 更新一次（首尾必更新），不减少文件中的输出帧。不重复复制另一套试听画布。主线程按时间片协作让出：支持时使用 `scheduler.yield`，否则使用定时任务；Shader 的资源等待以实际截止时间判断，避免更快的任务调度造成假超时。取消或错误时中止并收回提前绘制，再释放场景。

桌面桥 `rpenRenderOutput` API 1 只向当前受信主窗口公开 `begin/write/close/commit/abort/openFolder`。begin 显示保存对话框，返回不可猜测的 token；write 为有界随机位置写入（每次最多 1 MiB）；close 刷盘但不覆盖原文件；commit 完成后原子切换。成功保存后，面板右下角显示“打开所在文件夹”；openFolder 只接受当前窗口最后一次成功保存的 token，由主进程打开记录中的目标父目录，不接受任意路径。打开失败明确提示原因。失败和取消删除任务临时文件，保留旧目标。导航、渲染进程退出或窗口关闭清理任务及已完成 token；每个窗口最多保留一个已完成结果。路径由原生对话框选择，不能由 write 请求指定。

网页优先使用 File System Access，缺省使用 OPFS 临时文件；不会退回整个文件的 BufferTarget。OPFS 结果发起下载后可再次下载，关闭时清理临时文件。网页仅报告“已发起下载”，不声称浏览器文件已落盘。输出选择取消、编码取消、保存失败和保存成功分开报告。

## 渲染扩展和清理

`src/ui/render-extensions.mjs` 提供 `registerRenderExtension(attach)`。attach 接收新预览器和 purpose（`autoplay` / `export`），返回幂等释放函数。三维摄像机复用此入口；原有两个编辑器实例保持原行为。渲染也调用 `preview:before` 和相应覆盖层，回调必须使用传入的 chart/seconds，离线导出不依赖实际播放头。

`Preview.dispose()` 解绑字体监听，释放批绘制、Shader 与噪域资源以及辅助画布。加载和渲染分别有 AbortSignal、代次和最终清理；关闭后不接受过期结果。静止关闭面板无采样、无播放循环。待渲染的音乐或音效缺失/解码失败必须有明确原因，不静默导出残缺声音。

实际能力依设备的 WebCodecs 编码器而异；能力探测不代替各平台实测。

## 着色器事件与自定义代码

效果事件遵循 Phira extra.json 的 `effects` 结构；`start/end` 是拍数三元组，`global` 为是否作用于 UI，`vars` 保存参数常值或缓动轨道。RPEN 保留 `line/order` 等已有扩展字段，参数时间沿用所属线倍率和真实秒缓动，不因格式统一而改变。

`assets/rpe/shaders` 仅保留 40 个 GLSL 源文件，接口统一为 GLSL 1.00 的 `uv/screenTexture/screenSize/time`。原 Cocos 顶点文件、重复 `_2` 文件与独立的 pr 目录已移除。旧 `_2`、clone 和数值类型编号只在输入兼容映射中保留，所属线的旧默认映射保持稳定，同类事件每次独立叠加。部分旧谱指定的 RPE 效果与原 portable 效果存在实际差异，因此单文件包含同接口的兼容分支；运行时按旧引用选择，在编辑器中保留原视觉与默认值，不重新维护两套文件。内置接口兼容参数仍按原逻辑分辨率求值；用户自定义源码的 `screenSize` 为预览输入画面的实际物理像素尺寸，排除编辑器为布局、比例适配保留的外围区域。`uv`、`gl_FragCoord` 与 `screenTexture` 统一在此输入画面内定位，像素坐标从该画面的左下角开始；完整向量和 `.x/.y/.xy` 分量一致，深度和 w 分量保留。普通预览、侧边画面、代码面板与视频渲染共用适配，不改源码或谱面参数，不增加截图、中间纹理或逐帧源码处理。自定义参数不采用颜色 0–255 的自动换算。

自定义代码以 `/资源根路径` 引用，开头斜杠具有 Phira 的资源根语义，不以扩展名限制所引用的文件；GLSL 文件常见扩展名 `.glsl/.frag/.fs/.fsh` 均可导入和选择。相对路径仅用于旧资料兼容，不通过同名文件猜测而跨目录取代码。资源文件优先于同名内置效果；旧 `/xxx_pr.glsl` 引用在未附带实际文件时仍可映射内置源。源文件最大 256 KiB，UTF-8；编写时使用 `void main()`，可动画参数为 float、vec2、vec4，在 uniform 声明同行用 `%数值%` 指定默认值。错误来源和编译错误明确显示，失败结果缓存，不逐帧重复编译；两个预览器共用当前谱面的通知去重，同一问题在关闭谱面前最多弹报一次，不因图片刷新或播放切换重新提醒。缺失 Shader 在基础谱面检查的素材问题中按引用去重列出，使用后台已有文件名索引与播放一致的路径规则，只在谱面／素材改变时重算，不在逐帧绘制中扫描或读取源码。导出视频不能静默略过失效 Shader。

通用模板库保存在本机设置 `rpen-shader-library-v1`，格式见 schemas/shader-library-v1.schema.json，最多 256 项、8 MiB。存储使用原有本地设置服务，保留并发修改检查；模板库不写入谱面。新建、导入 GLSL 和加载内置代码生成独立草稿，内置文件始终只读。通用模板应用时以来源身份和源码 SHA-256 生成 `shaders/custom/<hash>.glsl`，在 `#version` 后附加 `// @rpen-template {"version":1,"name":"原名","chart":"谱名前缀","origin":"library:ID","revision":"来源版本散列"}` 注释（非通用来源可省略 origin/revision），不扩展 Phira 事件格式。编辑器显示“原名 · 谱面名的前六个 Unicode 字符”，包内引用保持稳定。元数据随 GLSL 保存和导出，外部播放器忽略该注释；旧散列资源仅在当前通用库仍有相同源码时恢复原名，否则显示 Shader。重新应用同一版本通用模板会复用其已经编辑过的谱面副本；通用模板更新产生新快照，不改旧副本。

打开谱面资源直接进入“谱面共享副本”编辑范围，显示本谱面引用数量；保存替换同一路径源码，所有引用事件同步生效，参数轨道保留，不改通用库或其他谱面。Ctrl+S 按当前范围保存。普通本地谱面源码保存支持撤销/重做及写入冲突检测；超大谱与联机继续沿用原有素材保存规则，资源改动需要保存，且不纳入普通谱面撤销/自动联机传输。需要只改所选事件时，先复制为独立草稿，再应用；也可将谱面源码另存为通用模板。独立草稿应用继续通过事件事务、支持一步撤销。导入谱面自带源码只加入当前谱面资源，并显示范围提示。

代码窗口编译后检查共享副本已有引用的参数，删除定义或改变维数会显示提示；保存后基础谱面检查自动列出每个不匹配事件，不自动删除原参数。uniform 定义按源码字节对象缓存，仅在谱面或素材变化时提交精简定义给检查 Worker，不在绘制循环中读取源码。通用库按存储文本缓存验证结果。参数轨道只在谱面编译时排序并缓存拍数，播放二分取值；未变化的源码在无关图片刷新时复用，代码面板关闭后没有额外循环。

代码窗口由 `shader-tool.mjs` 按需加载，默认暂停。谱面场景使用独立 Preview，面板时间同时驱动判定线、音符、事件参数与 Shader；替换待编辑效果的源码及试调值，保留其他效果及普通／全局合成阶段，避免对已含该 Shader 的快照再次叠加。事件范围外或未选中事件时以独立全局试算显示草稿。也可切换独立测试图；测试图仅随 Shader 本身的时间逻辑变化。播放、手动时间和刷新均不移动主界面播放位置，不播放任何声音。超大谱使用独立、有界预览窗口，异步读取只保留一个请求并丢弃过期结果，不修改主预览和音效缓存。暂停后仅在输入、资源就绪或主动刷新时重绘，关闭释放独立场景和绘制资源。提供语法高亮、行号、查找、缩进、实时错误与参数试调；Ctrl+S 保存，Ctrl+Enter 编译，Ctrl+F 查找，Esc 关闭；取消直接丢弃尚未保存的代码、名称与试调参数并退出，已经保存或应用的内容保留，保存进行中暂不可取消。试调参数不写源码或事件。文本输入层保持透明，字符样式、内边距和边框与高亮层一致，避免皮肤的全局输入框与选中文字样式造成重影。窗口位置和尺寸保存于本机设置，关闭取消动画、编译延时、观察器与监听并释放 GPU 资源。图表切换或回首页会关闭窗口，选择改变后禁止应用到旧选择。未打开时不创建代码编辑器、预览循环或额外 GPU 上下文。

PEZ 导出先在导出副本中准备实际引用的内置扩展效果，生成可独立分发的 Phira GLSL 及根路径引用；原谱、素材和选择不改变。自定义文件作为普通素材随工程保存和恢复，通过原引用遍历筛选，默认不携带未使用源码，也不携带通用库的其他模板。旧内置基础效果仍按 Phira 内置名引用。代码资源不会覆盖包内已有不同内容文件。JSON 与贴图、音频一致，只保存资源引用；跨设备携带请用 PEZ。

## 编辑器整窗定帧录制

这是独立于 Autoplay 渲染面板的桌面播放渲染功能。默认 `EditorRecording = LEFTCTRL&LEFTSHIFT&U`，沿用快捷键设置与输入焦点保护。统一设置 `#editor-render-settings` 是默认折叠的 details，搜索命中时沿用设置搜索自动展开／恢复；`editorRenderFps` 为 1–240 的整数，默认 60，与普通界面帧率上限无关。`editorRenderAutoPlay` 默认 true。独立的按键显示设置 `keyDisplay` 默认 false，快捷键为 `KeyDisplay = LEFTCTRL&LEFTSHIFT&K`，进入原有快捷键编辑器，可单独修改。

播放渲染不切换当前编辑／预览模式，开始时按自动播放设置和原播放状态决定是否播放；关闭自动播放且原先暂停时保持静止，手动播放／暂停可继续同一段输出，暂停段声音为静音。到实际播放结尾或再次快捷键后封装并保存片段。循环播放在此模式不回跳；跳转、修改谱面、改变倍速、声部混音或音频设置仍会结束此次片段。启用按键显示时叠加层与其他软件 UI 一同进入完整客户区视频。

`src/ui/editor-recording.mjs` 为轻量入口，任务启动时才动态加载控制器、音频、捕获与编码模块。播放渲染由 `src/application/editor-frame-clock.mjs` 临时安装帧时钟，普通 RAF 在此期间不推进主画面；播放时每帧前进 `倍速/目标帧率`，暂停时不前进。`RecordingPlaybackAudio` 记录播放／暂停分段，将输出帧时钟映射回音乐时钟。捕获或编码变慢只延长生成时间，不省略输出帧。退出恢复音频方法、时钟、动画和背景节流设置，停留在片段终点；取消保存选择恢复原播放状态。

`rpenEditorCapture` API 1 提供 `call('begin', {raw:true}) → {ok,result:{id,format,fence}}`、`call('frame', id或{id,fence}) → {ok,result:{width,height,format,stride?,bytes}}` 与 `call('end', id)`。桥仅允许受信主窗口主 frame，token 属于当前任务，单次只允许一个截图请求。优先返回客户区原始物理像素 BGRA/RGBA，按任务用已知颜色探测本平台位图格式，不根据系统名称猜测；未知格式或旧桥回退无损 PNG。不包括操作系统标题栏、鼠标指针和原生菜单；不缩放或重建 DOM，不改变皮肤和普通预览特效。原始像素直接构造 `VideoFrame` 送 `VideoSampleSource`，绕过 PNG 压缩／解码及中间画布。预载的可选 `requestFrame(requestId,value)` 使用消息转移帧 buffer，避免 contextBridge 再次深拷贝；接收监听仅在录制任务存在，支持引擎还会将 buffer 所有权转给 VideoFrame。旧桥保留 `call('frame',id)` 兼容路径。像素预算 32 Mi pixels，单帧上限 128 MiB；尺寸／DPI 变化结束并保存此前片段，不拉伸画面。主进程在导航、崩溃或退出时恢复捕获状态。

录制状态按钮底部的紧凑像素进度条同时携带帧标记：每次完整画面绘制后更新，主进程只接受与当前标记一致的合成结果。旧表面立即丢弃并重取，不作为输出帧，也不改变音视频时间戳。最多保留当前截图，无后台截图队列；超过 5 秒仍未完成合成会明确失败并恢复。皮肤隐藏状态条时回退等待绘制提交。新模块的加载、帧标记、像素格式探测、消息监听与图像资源均只在录制期间存在。

`createVideoEncodingSession` 采用增量封装，视频时戳为帧号/目标帧率，每帧时长固定。音频按至多半秒读取及交错写入，最终按实际帧数收尾，不预先分配整段音频或视频。优先 MP4，奇数窗口尺寸或编码能力不满足时使用 WebM，始终保留原像素尺寸；无可用音视频编码器则明确失败。文件输出复用原子 `.part` 写入，失败保留旧文件。

音频复用当前 `playbackBuffer`（含选中声部混音）、音乐与音效音量、每类音效延迟、当前线静音策略及皮肤音效。判定点按音乐时钟转换，音效样本保持原速；不保调的倍速采用采样率转换，保调倍速采用有界 WSOLA，保留音高，但不保证与各平台实时媒体保调算法逐样本相同。超大谱音效继续按磁盘索引短段读取；录制每帧等待可见编辑页与预览窗口就绪，不能仅录制缓存缺页画面。录制过程中修改或切换谱面会结束片段，避免音画来自不同文档。

皮肤别名 `@editor-recording-status` 和 `@editor-render-fps` 对应按需状态控件与帧率设置。录制关闭时无编码器、截图、音频转换、动画遍历或额外定时器；主循环只检查是否正在录制。Electron 的 Windows/macOS/Linux 共用捕获代码，平台实测分别记录；网页无法保证等价整窗离线捕获时明确提示，不退回实时掉帧录屏。

### 独立按键显示

`src/ui/key-display-tool.mjs` 为轻量入口，仅启用时动态加载 `key-display.mjs` 与键帽状态，关闭后移除全部键帽、DOM、动画帧和失焦监听。复用软件已有输入入口，不拦截或重演编辑操作，不读写磁盘日志、整谱缓存或音频设备。

键帽显示最近按键组合、鼠标按钮与滚轮，连续重复合并计数；右下角顶层叠加向上浮动，按距离和寿命淡出，队列有界。密码／显式私密区域与 IME 未完成状态不显示。开关本身不作为操作记录展示；真实文本输入不穿透成谱面快捷键。普通使用仅在有键帽时动画，队列清空后停止；播放渲染时改用输出帧时钟，结束后恢复，避免编码速度改变键帽寿命。

播放渲染不调用 getUserMedia/getDisplayMedia，不申请麦克风、系统录音或桌面音频权限。只离线混合编辑器当前音乐／声部与打击音效。
