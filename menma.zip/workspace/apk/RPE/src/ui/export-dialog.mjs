import { prepareShaderExport } from '../platform/shader-export.mjs';
import { showDialog } from './dialog.mjs';
import { createChartExport, download, suggestDownloadName } from '../platform/files.mjs';
import { chartExportStem } from '../core/export-filename.mjs';
import { DEFAULT_TRAJECTORY_SPLIT } from '../core/trajectory-simplify.mjs';
import { diagnoseNoiseAreas } from '../core/noise-areas.mjs';
import { DEFAULT_BEZIER_EXPORT_MARGIN } from '../core/bezier-compat.mjs';
import { t } from '../i18n.mjs';

export function showExportDialog(chart, assets, chartName, onExport, identifier, { includeBackupCharts = false } = {}) {
  const host = showDialog(t('export-dialog.s50e57e1'), t('export-dialog.s80099ed'));
  const field = (title, control) => { const label = document.createElement('label'); label.className = 'field'; label.append(title, control); control.setAttribute('aria-label', title); host.append(label); return control; };
  const format = document.createElement('select');
  for (const [value, title] of [['next:json', 'RPE Next · JSON'], ['next:pez', 'RPE Next · PEZ'], ['rpe:json', t('export-dialog.s63c70f0')], ['rpe:pez', t('export-dialog.saacf5fd')]]) format.append(new Option(title, value));
  format.value = 'next:pez'; field(t('export-dialog.s3b1cd5c'), format);
  const compact = document.createElement('input'); compact.type = 'checkbox'; compact.checked = true;
  field(t('export-dialog.sa7bc6e7'), compact);
  const unused = document.createElement('input'); unused.type = 'checkbox'; unused.checked = false;
  field(t('export-dialog.sb87f1b3'), unused); const unusedLabel = unused.closest('label');
  const unusedHint = document.createElement('p'); unusedHint.className = 'hint'; unusedHint.textContent = t('export-dialog.s91d63d9'); host.append(unusedHint);
  const noiseIssues = diagnoseNoiseAreas(chart.blockAreaList);
  const noiseWarning = document.createElement('div'); noiseWarning.className = 'noise-export-warning'; host.append(noiseWarning);
  const acknowledgement = document.createElement('input'); acknowledgement.type = 'checkbox';
  const acknowledgementLabel = document.createElement('label'); acknowledgementLabel.className = 'field'; acknowledgementLabel.append(acknowledgement, t('export-dialog.s00bc416')); acknowledgementLabel.hidden = !noiseIssues.length; host.append(acknowledgementLabel);
  const removeNoise = document.createElement('input'); removeNoise.type = 'checkbox';
  const removeLabel = document.createElement('label'); removeLabel.className = 'field'; removeLabel.append(removeNoise, t('export-dialog.s3f5a158')); host.append(removeLabel);
  const hasGlobalEvents = Object.values(chart.globalEvents?.types ?? {}).some(type => Object.values(type.columns).some(column => column.events.length));
  const removeGlobal = document.createElement('input'); removeGlobal.type = 'checkbox';
  const removeGlobalLabel = document.createElement('label'); removeGlobalLabel.className = 'field'; removeGlobalLabel.append(removeGlobal, t('export-dialog.sffad927')); host.append(removeGlobalLabel);
  if (noiseIssues.length) { const heading = document.createElement('p'); heading.textContent = t('export-dialog.s80ad627') + noiseIssues.length + t('export-dialog.s30ed317'); noiseWarning.append(heading); for (const issue of noiseIssues.slice(0, 20)) { const item = document.createElement('p'); item.textContent = issue.path + '：' + issue.message; noiseWarning.append(item); } }
  const name = field(t('export-dialog.s2315651'), document.createElement('input'));
  const defaultStem = chartExportStem(chart, chartName);
  let suggestedStem;
  const suggestName = () => {
    if (suggestedStem !== undefined && name.value !== suggestedStem) return;
    const extension = '.' + format.value.split(':')[1];
    suggestedStem = suggestDownloadName(defaultStem + extension).slice(0, -extension.length);
    name.value = suggestedStem;
  };
  suggestName();
  const settings = document.createElement('fieldset'); const legend = document.createElement('legend'); legend.textContent = t('export-dialog.sf738992'); settings.append(legend);
  const simplify = document.createElement('input'); simplify.type = 'checkbox'; simplify.checked = DEFAULT_TRAJECTORY_SPLIT.simplify;
  const simplifyLabel = document.createElement('label'); simplifyLabel.className = 'field'; simplifyLabel.append(simplify, t('export-dialog.s8160e72')); simplify.setAttribute('aria-label', t('export-dialog.s8160e72'));
  const tolerance = document.createElement('input'); tolerance.type = 'number'; tolerance.min = '0.001'; tolerance.max = '10000'; tolerance.step = 'any'; tolerance.value = DEFAULT_TRAJECTORY_SPLIT.tolerance; tolerance.setAttribute('aria-label', t('export-dialog.s413683d'));
  const toleranceLabel = document.createElement('label'); toleranceLabel.className = 'field'; toleranceLabel.append(t('export-dialog.s413683d'), tolerance);
  const bake = document.createElement('input'); bake.type = 'checkbox'; bake.checked = true;
  const bakeLabel = document.createElement('label'); bakeLabel.className = 'field'; bakeLabel.append(bake, t('animation-curve.bake'));
  const bakeHint = document.createElement('p'); bakeHint.className = 'hint'; bakeHint.textContent = t('animation-curve.bakeHint'); settings.append(bakeLabel, bakeHint);
  const hint = document.createElement('p'); hint.className = 'hint'; hint.textContent = t('export-dialog.s9f1c3f8');
  settings.append(simplifyLabel, toleranceLabel, hint); host.append(settings);
  const clampBezier = document.createElement('input'); clampBezier.type = 'checkbox'; clampBezier.checked = false;
  field(t('export-dialog.s37ee0de'), clampBezier); const clampLabel = clampBezier.closest('label');
  const margin = document.createElement('input'); margin.type = 'number'; margin.min = '0.001'; margin.max = '0.25'; margin.step = '0.001'; margin.value = DEFAULT_BEZIER_EXPORT_MARGIN;
  field(t('export-dialog.s8ee1ff0'), margin); const marginLabel = margin.closest('label');
  const bezierHint = document.createElement('p'); bezierHint.className = 'hint'; bezierHint.textContent = t('export-dialog.s2572162'); host.append(bezierHint);
  const sync = () => { const legacy = format.value.startsWith('rpe:'); unusedLabel.hidden = unusedHint.hidden = format.value.endsWith(':json'); settings.hidden = !legacy; tolerance.disabled = !simplify.checked; removeLabel.hidden = !chart.blockAreaList?.length || !legacy; removeGlobalLabel.hidden = !hasGlobalEvents || !legacy; clampLabel.hidden = bezierHint.hidden = !legacy; marginLabel.hidden = !legacy || !clampBezier.checked; margin.disabled = !legacy || !clampBezier.checked; };
  format.onchange = () => { suggestName(); sync(); }; simplify.onchange = clampBezier.onchange = sync; sync();
  const apply = document.querySelector('#modal-apply'); apply.hidden = false; apply.textContent = t('export-dialog.s1888967');
  apply.onclick = async () => {
    if (apply.disabled) return; apply.disabled = true;
    try {
      const [compatibility, container] = format.value.split(':');
      if (noiseIssues.length && !acknowledgement.checked) throw new Error(t('export-dialog.s4094dae'));
      if (compatibility === 'rpe' && chart.blockAreaList?.length && !removeNoise.checked) throw new Error(t('export-dialog.sac6ba5f'));
      if (compatibility === 'rpe' && hasGlobalEvents && !removeGlobal.checked) throw Error(t('export-dialog.se25f82b'));
      const prepared = container === 'pez' ? await prepareShaderExport(chart, assets, chartName) : { chart, assets };
      const result = createChartExport(prepared.chart, prepared.assets, chartName, { bakeCustomEasing: bake.checked, includeUnusedFiles: unused.checked, includeBackupCharts, compatibility, format: container, compact: compact.checked, name: name.value, identifier, clampBezier: compatibility === 'rpe' && clampBezier.checked, bezierMargin: Number(margin.value), removeNoiseAreas: compatibility === 'rpe' && removeNoise.checked, removeGlobalEvents: compatibility === 'rpe' && removeGlobal.checked, split: { simplify: simplify.checked, tolerance: Number(tolerance.value) } });
      const filename = download(result.blob, result.name); document.querySelector('#modal').close(); onExport(filename, container);
    } catch (error) { document.querySelector('#modal-error').textContent = error.message; }
    finally { apply.disabled = false; }
  };
}
